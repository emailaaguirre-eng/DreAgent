"""
Lea Agentic Task System
Allows Lea to autonomously perform pre-configured tasks
"""

import os
import json
import logging
import subprocess
import shutil
from pathlib import Path
from typing import Dict, List, Any, Callable, Optional, Tuple
from datetime import datetime
from abc import ABC, abstractmethod

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class TaskResult:
    """Result of a task execution"""
    def __init__(self, success: bool, message: str, data: Any = None, error: str = None):
        self.success = success
        self.message = message
        self.data = data
        self.error = error
    
    def to_dict(self):
        return {
            'success': self.success,
            'message': self.message,
            'data': self.data,
            'error': self.error
        }


class BaseTask(ABC):
    """Base class for all tasks that Lea can perform"""
    
    def __init__(self, name: str, description: str, requires_confirmation: bool = False):
        self.name = name
        self.description = description
        self.requires_confirmation = requires_confirmation
        self.allowed = True  # Can be disabled via config
    
    @abstractmethod
    def execute(self, **kwargs) -> TaskResult:
        """Execute the task. Must be implemented by subclasses."""
        pass
    
    def validate_params(self, **kwargs) -> Tuple[bool, str]:
        """Validate task parameters. Override if needed."""
        return True, ""
    
    def get_required_params(self) -> List[str]:
        """Return list of required parameter names. Override if needed."""
        return []


# =====================================================
# FILE OPERATIONS TASKS
# =====================================================

class FileCopyTask(BaseTask):
    """Copy files from source to destination"""
    
    def __init__(self):
        super().__init__(
            name="file_copy",
            description="Copy a file from source to destination",
            requires_confirmation=False
        )
    
    def get_required_params(self) -> List[str]:
        return ["source", "destination"]
    
    def validate_params(self, **kwargs) -> Tuple[bool, str]:
        source = kwargs.get("source")
        destination = kwargs.get("destination")
        
        if not source:
            return False, "Source path is required"
        if not destination:
            return False, "Destination path is required"
        if not os.path.exists(source):
            return False, f"Source file does not exist: {source}"
        
        return True, ""
    
    def execute(self, **kwargs) -> TaskResult:
        try:
            source = kwargs.get("source")
            destination = kwargs.get("destination")
            
            # Validate
            valid, msg = self.validate_params(**kwargs)
            if not valid:
                return TaskResult(False, msg, error=msg)
            
            # Ensure destination directory exists
            dest_path = Path(destination)
            dest_path.parent.mkdir(parents=True, exist_ok=True)
            
            # Copy file
            shutil.copy2(source, destination)
            
            return TaskResult(
                True,
                f"File copied successfully from {source} to {destination}",
                data={"source": source, "destination": destination}
            )
        except Exception as e:
            logger.error(f"FileCopyTask error: {e}")
            return TaskResult(False, f"Failed to copy file: {str(e)}", error=str(e))


class FileMoveTask(BaseTask):
    """Move files from source to destination"""
    
    def __init__(self):
        super().__init__(
            name="file_move",
            description="Move a file from source to destination",
            requires_confirmation=True
        )
    
    def get_required_params(self) -> List[str]:
        return ["source", "destination"]
    
    def validate_params(self, **kwargs) -> Tuple[bool, str]:
        source = kwargs.get("source")
        destination = kwargs.get("destination")
        
        if not source:
            return False, "Source path is required"
        if not destination:
            return False, "Destination path is required"
        if not os.path.exists(source):
            return False, f"Source file does not exist: {source}"
        
        return True, ""
    
    def execute(self, **kwargs) -> TaskResult:
        try:
            source = kwargs.get("source")
            destination = kwargs.get("destination")
            
            valid, msg = self.validate_params(**kwargs)
            if not valid:
                return TaskResult(False, msg, error=msg)
            
            dest_path = Path(destination)
            dest_path.parent.mkdir(parents=True, exist_ok=True)
            
            shutil.move(source, destination)
            
            return TaskResult(
                True,
                f"File moved successfully from {source} to {destination}",
                data={"source": source, "destination": destination}
            )
        except Exception as e:
            logger.error(f"FileMoveTask error: {e}")
            return TaskResult(False, f"Failed to move file: {str(e)}", error=str(e))


class FileDeleteTask(BaseTask):
    """Delete files or directories"""
    
    def __init__(self):
        super().__init__(
            name="file_delete",
            description="Delete a file or directory",
            requires_confirmation=True
        )
    
    def get_required_params(self) -> List[str]:
        return ["path"]
    
    def validate_params(self, **kwargs) -> Tuple[bool, str]:
        path = kwargs.get("path")
        
        if not path:
            return False, "Path is required"
        if not os.path.exists(path):
            return False, f"Path does not exist: {path}"
        
        # Safety check - prevent deletion of critical paths
        critical_paths = [
            os.path.expanduser("~/.ssh"),
            os.path.expanduser("~/Documents"),
            "C:\\Windows",
            "/etc",
            "/usr",
            "/bin",
        ]
        
        abs_path = os.path.abspath(path)
        for critical in critical_paths:
            if critical in abs_path:
                return False, f"Cannot delete critical path: {path}"
        
        return True, ""
    
    def execute(self, **kwargs) -> TaskResult:
        try:
            path = kwargs.get("path")
            
            valid, msg = self.validate_params(**kwargs)
            if not valid:
                return TaskResult(False, msg, error=msg)
            
            path_obj = Path(path)
            if path_obj.is_file():
                path_obj.unlink()
                action = "deleted"
            elif path_obj.is_dir():
                shutil.rmtree(path)
                action = "deleted directory"
            else:
                return TaskResult(False, f"Path is neither file nor directory: {path}")
            
            return TaskResult(
                True,
                f"Successfully {action}: {path}",
                data={"path": path, "action": action}
            )
        except Exception as e:
            logger.error(f"FileDeleteTask error: {e}")
            return TaskResult(False, f"Failed to delete: {str(e)}", error=str(e))


class FileReadTask(BaseTask):
    """Read file contents"""
    
    def __init__(self):
        super().__init__(
            name="file_read",
            description="Read contents of a text file",
            requires_confirmation=False
        )
    
    def get_required_params(self) -> List[str]:
        return ["path"]
    
    def validate_params(self, **kwargs) -> Tuple[bool, str]:
        path = kwargs.get("path")
        
        if not path:
            return False, "Path is required"
        if not os.path.exists(path):
            return False, f"File does not exist: {path}"
        if not os.path.isfile(path):
            return False, f"Path is not a file: {path}"
        
        return True, ""
    
    def execute(self, **kwargs) -> TaskResult:
        try:
            path = kwargs.get("path")
            encoding = kwargs.get("encoding", "utf-8")
            max_size = kwargs.get("max_size", 10 * 1024 * 1024)  # 10MB default
            
            valid, msg = self.validate_params(**kwargs)
            if not valid:
                return TaskResult(False, msg, error=msg)
            
            # Check file size
            file_size = os.path.getsize(path)
            if file_size > max_size:
                return TaskResult(
                    False,
                    f"File too large ({file_size} bytes). Max size: {max_size} bytes",
                    error="File too large"
                )
            
            with open(path, 'r', encoding=encoding, errors='ignore') as f:
                content = f.read()
            
            return TaskResult(
                True,
                f"Successfully read file: {path}",
                data={"path": path, "content": content, "size": file_size}
            )
        except Exception as e:
            logger.error(f"FileReadTask error: {e}")
            return TaskResult(False, f"Failed to read file: {str(e)}", error=str(e))


class FileWriteTask(BaseTask):
    """Write content to a file"""
    
    def __init__(self):
        super().__init__(
            name="file_write",
            description="Write content to a file",
            requires_confirmation=False
        )
    
    def get_required_params(self) -> List[str]:
        return ["path", "content"]
    
    def validate_params(self, **kwargs) -> Tuple[bool, str]:
        path = kwargs.get("path")
        
        if not path:
            return False, "Path is required"
        
        # Safety check
        critical_paths = ["C:\\Windows", "/etc", "/usr", "/bin"]
        abs_path = os.path.abspath(path)
        for critical in critical_paths:
            if critical in abs_path:
                return False, f"Cannot write to critical path: {path}"
        
        return True, ""
    
    def execute(self, **kwargs) -> TaskResult:
        try:
            path = kwargs.get("path")
            content = kwargs.get("content", "")
            encoding = kwargs.get("encoding", "utf-8")
            mode = kwargs.get("mode", "w")  # 'w' for write, 'a' for append
            
            valid, msg = self.validate_params(**kwargs)
            if not valid:
                return TaskResult(False, msg, error=msg)
            
            # Ensure directory exists
            path_obj = Path(path)
            path_obj.parent.mkdir(parents=True, exist_ok=True)
            
            with open(path, mode, encoding=encoding) as f:
                f.write(str(content))
            
            return TaskResult(
                True,
                f"Successfully wrote to file: {path}",
                data={"path": path, "mode": mode, "size": len(str(content))}
            )
        except Exception as e:
            logger.error(f"FileWriteTask error: {e}")
            return TaskResult(False, f"Failed to write file: {str(e)}", error=str(e))


# =====================================================
# DIRECTORY OPERATIONS TASKS
# =====================================================

class DirectoryCreateTask(BaseTask):
    """Create directories"""
    
    def __init__(self):
        super().__init__(
            name="directory_create",
            description="Create a directory (and parent directories if needed)",
            requires_confirmation=False
        )
    
    def get_required_params(self) -> List[str]:
        return ["path"]
    
    def execute(self, **kwargs) -> TaskResult:
        try:
            path = kwargs.get("path")
            if not path:
                return TaskResult(False, "Path is required", error="Missing path")
            
            Path(path).mkdir(parents=True, exist_ok=True)
            
            return TaskResult(
                True,
                f"Directory created (or already exists): {path}",
                data={"path": path}
            )
        except Exception as e:
            logger.error(f"DirectoryCreateTask error: {e}")
            return TaskResult(False, f"Failed to create directory: {str(e)}", error=str(e))


class DirectoryListTask(BaseTask):
    """List directory contents"""
    
    def __init__(self):
        super().__init__(
            name="directory_list",
            description="List files and directories in a path",
            requires_confirmation=False
        )
    
    def get_required_params(self) -> List[str]:
        return ["path"]
    
    def execute(self, **kwargs) -> TaskResult:
        try:
            path = kwargs.get("path", ".")
            if not os.path.exists(path):
                return TaskResult(False, f"Path does not exist: {path}", error="Path not found")
            
            items = []
            for item in os.listdir(path):
                item_path = os.path.join(path, item)
                items.append({
                    "name": item,
                    "path": item_path,
                    "type": "directory" if os.path.isdir(item_path) else "file",
                    "size": os.path.getsize(item_path) if os.path.isfile(item_path) else None
                })
            
            return TaskResult(
                True,
                f"Listed {len(items)} items in {path}",
                data={"path": path, "items": items, "count": len(items)}
            )
        except Exception as e:
            logger.error(f"DirectoryListTask error: {e}")
            return TaskResult(False, f"Failed to list directory: {str(e)}", error=str(e))


# =====================================================
# TEXT PROCESSING TASKS
# =====================================================

class TextReplaceTask(BaseTask):
    """Replace text in a file"""
    
    def __init__(self):
        super().__init__(
            name="text_replace",
            description="Find and replace text in a file",
            requires_confirmation=True
        )
    
    def get_required_params(self) -> List[str]:
        return ["path", "old_text", "new_text"]
    
    def execute(self, **kwargs) -> TaskResult:
        try:
            path = kwargs.get("path")
            old_text = kwargs.get("old_text")
            new_text = kwargs.get("new_text", "")
            encoding = kwargs.get("encoding", "utf-8")
            
            if not path or old_text is None:
                return TaskResult(False, "Path and old_text are required", error="Missing parameters")
            
            if not os.path.exists(path):
                return TaskResult(False, f"File does not exist: {path}", error="File not found")
            
            # Read file
            with open(path, 'r', encoding=encoding) as f:
                content = f.read()
            
            # Replace
            if old_text not in content:
                return TaskResult(False, f"Text not found in file: {old_text}", error="Text not found")
            
            new_content = content.replace(old_text, new_text)
            replacements = content.count(old_text)
            
            # Write back
            with open(path, 'w', encoding=encoding) as f:
                f.write(new_content)
            
            return TaskResult(
                True,
                f"Replaced '{old_text}' with '{new_text}' ({replacements} occurrences) in {path}",
                data={"path": path, "replacements": replacements}
            )
        except Exception as e:
            logger.error(f"TextReplaceTask error: {e}")
            return TaskResult(False, f"Failed to replace text: {str(e)}", error=str(e))


# =====================================================
# SYSTEM COMMAND TASK (with safety)
# =====================================================

class SystemCommandTask(BaseTask):
    """Execute system commands (safely)"""
    
    def __init__(self):
        super().__init__(
            name="system_command",
            description="Execute a system command (whitelist only)",
            requires_confirmation=True
        )
        
        # Whitelist of allowed commands/patterns
        self.allowed_commands = [
            "python", "python3",
            "pip", "pip3",
            "git",
            "echo",
            "dir", "ls",
            "cd",
        ]
        
        # Blocked commands
        self.blocked_commands = [
            "rm", "del", "format", "fdisk",
            "sudo", "su",
            "chmod 777", "chmod +x",
        ]
    
    def get_required_params(self) -> List[str]:
        return ["command"]
    
    def validate_params(self, **kwargs) -> Tuple[bool, str]:
        command = kwargs.get("command", "")
        
        if not command:
            return False, "Command is required"
        
        # Check for blocked commands
        command_lower = command.lower()
        for blocked in self.blocked_commands:
            if blocked in command_lower:
                return False, f"Blocked command: {blocked}"
        
        # For safety, only allow whitelisted commands or explicit approval
        approved = kwargs.get("approved", False)
        if not approved:
            # Check if command starts with allowed command
            first_word = command.split()[0] if command.split() else ""
            if first_word.lower() not in [cmd.lower() for cmd in self.allowed_commands]:
                return False, f"Command not in whitelist. First word: {first_word}. Set approved=True to allow."
        
        return True, ""
    
    def execute(self, **kwargs) -> TaskResult:
        try:
            command = kwargs.get("command")
            timeout = kwargs.get("timeout", 30)
            shell = kwargs.get("shell", True)
            
            valid, msg = self.validate_params(**kwargs)
            if not valid:
                return TaskResult(False, msg, error=msg)
            
            # Execute command
            result = subprocess.run(
                command,
                shell=shell,
                capture_output=True,
                text=True,
                timeout=timeout
            )
            
            output = result.stdout + result.stderr
            
            if result.returncode == 0:
                return TaskResult(
                    True,
                    f"Command executed successfully: {command}",
                    data={"command": command, "output": output, "returncode": result.returncode}
                )
            else:
                return TaskResult(
                    False,
                    f"Command failed with return code {result.returncode}: {command}",
                    data={"command": command, "output": output, "returncode": result.returncode},
                    error=output
                )
        except subprocess.TimeoutExpired:
            return TaskResult(False, f"Command timed out after {timeout} seconds", error="Timeout")
        except Exception as e:
            logger.error(f"SystemCommandTask error: {e}")
            return TaskResult(False, f"Failed to execute command: {str(e)}", error=str(e))


# =====================================================
# SCREEN AUTOMATION TASKS
# =====================================================

class ScreenshotTask(BaseTask):
    """Take a screenshot of the screen"""
    
    def __init__(self):
        super().__init__(
            name="screenshot",
            description="Take a screenshot of the entire screen or a region",
            requires_confirmation=False
        )
    
    def execute(self, **kwargs) -> TaskResult:
        try:
            # Try to import pyautogui
            try:
                import pyautogui
            except ImportError:
                return TaskResult(
                    False,
                    "pyautogui not installed. Install with: pip install pyautogui",
                    error="Module not found"
                )
            
            # Optional parameters
            region = kwargs.get("region")  # (x, y, width, height)
            save_path = kwargs.get("save_path")
            
            if region and len(region) == 4:
                screenshot = pyautogui.screenshot(region=region)
            else:
                screenshot = pyautogui.screenshot()
            
            if save_path:
                screenshot.save(save_path)
                return TaskResult(
                    True,
                    f"Screenshot saved to: {save_path}",
                    data={"path": save_path, "size": screenshot.size}
                )
            else:
                # Save to temp location
                import tempfile
                temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.png')
                screenshot.save(temp_file.name)
                return TaskResult(
                    True,
                    f"Screenshot taken and saved to: {temp_file.name}",
                    data={"path": temp_file.name, "size": screenshot.size}
                )
        except Exception as e:
            logger.error(f"ScreenshotTask error: {e}")
            return TaskResult(False, f"Failed to take screenshot: {str(e)}", error=str(e))


class ClickTask(BaseTask):
    """Click at a specific location on screen"""
    
    def __init__(self):
        super().__init__(
            name="click",
            description="Click at specific coordinates on the screen",
            requires_confirmation=True  # Require confirmation for safety
        )
    
    def get_required_params(self) -> List[str]:
        return ["x", "y"]
    
    def validate_params(self, **kwargs) -> Tuple[bool, str]:
        x = kwargs.get("x")
        y = kwargs.get("y")
        
        if x is None or y is None:
            return False, "x and y coordinates are required"
        
        try:
            x, y = int(x), int(y)
            # Get screen size to validate
            try:
                import pyautogui
                screen_width, screen_height = pyautogui.size()
                if x < 0 or x >= screen_width or y < 0 or y >= screen_height:
                    return False, f"Coordinates ({x}, {y}) are outside screen bounds ({screen_width}x{screen_height})"
            except ImportError:
                pass  # Will be caught in execute
        except (ValueError, TypeError):
            return False, "x and y must be valid integers"
        
        return True, ""
    
    def execute(self, **kwargs) -> TaskResult:
        try:
            try:
                import pyautogui
            except ImportError:
                return TaskResult(
                    False,
                    "pyautogui not installed. Install with: pip install pyautogui",
                    error="Module not found"
                )
            
            x = int(kwargs.get("x"))
            y = int(kwargs.get("y"))
            button = kwargs.get("button", "left")  # left, right, middle
            clicks = kwargs.get("clicks", 1)
            interval = kwargs.get("interval", 0.0)
            
            pyautogui.click(x, y, button=button, clicks=clicks, interval=interval)
            
            return TaskResult(
                True,
                f"Clicked at ({x}, {y}) with {button} button ({clicks} clicks)",
                data={"x": x, "y": y, "button": button, "clicks": clicks}
            )
        except Exception as e:
            logger.error(f"ClickTask error: {e}")
            return TaskResult(False, f"Failed to click: {str(e)}", error=str(e))


class TypeTask(BaseTask):
    """Type text at the current cursor position"""
    
    def __init__(self):
        super().__init__(
            name="type",
            description="Type text at the current cursor position",
            requires_confirmation=True  # Require confirmation for safety
        )
    
    def get_required_params(self) -> List[str]:
        return ["text"]
    
    def validate_params(self, **kwargs) -> Tuple[bool, str]:
        text = kwargs.get("text")
        if not text:
            return False, "Text to type is required"
        return True, ""
    
    def execute(self, **kwargs) -> TaskResult:
        try:
            try:
                import pyautogui
            except ImportError:
                return TaskResult(
                    False,
                    "pyautogui not installed. Install with: pip install pyautogui",
                    error="Module not found"
                )
            
            text = str(kwargs.get("text", ""))
            interval = kwargs.get("interval", 0.0)  # Delay between keystrokes
            
            pyautogui.write(text, interval=interval)
            
            return TaskResult(
                True,
                f"Typed text: {text[:50]}{'...' if len(text) > 50 else ''}",
                data={"text_length": len(text), "interval": interval}
            )
        except Exception as e:
            logger.error(f"TypeTask error: {e}")
            return TaskResult(False, f"Failed to type text: {str(e)}", error=str(e))


class KeyPressTask(BaseTask):
    """Press a key or key combination"""
    
    def __init__(self):
        super().__init__(
            name="key_press",
            description="Press a key or key combination (e.g., 'enter', 'ctrl+c')",
            requires_confirmation=True
        )
    
    def get_required_params(self) -> List[str]:
        return ["key"]
    
    def execute(self, **kwargs) -> TaskResult:
        try:
            try:
                import pyautogui
            except ImportError:
                return TaskResult(
                    False,
                    "pyautogui not installed. Install with: pip install pyautogui",
                    error="Module not found"
                )
            
            key = kwargs.get("key", "")
            presses = kwargs.get("presses", 1)
            interval = kwargs.get("interval", 0.0)
            
            if not key:
                return TaskResult(False, "Key is required", error="Missing key")
            
            pyautogui.press(key, presses=presses, interval=interval)
            
            return TaskResult(
                True,
                f"Pressed key: {key} ({presses} times)",
                data={"key": key, "presses": presses}
            )
        except Exception as e:
            logger.error(f"KeyPressTask error: {e}")
            return TaskResult(False, f"Failed to press key: {str(e)}", error=str(e))


class HotkeyTask(BaseTask):
    """Press a hotkey combination (e.g., Ctrl+C, Alt+Tab)"""
    
    def __init__(self):
        super().__init__(
            name="hotkey",
            description="Press a hotkey combination (e.g., 'ctrl+c', 'alt+tab')",
            requires_confirmation=True
        )
    
    def get_required_params(self) -> List[str]:
        return ["keys"]
    
    def execute(self, **kwargs) -> TaskResult:
        try:
            try:
                import pyautogui
            except ImportError:
                return TaskResult(
                    False,
                    "pyautogui not installed. Install with: pip install pyautogui",
                    error="Module not found"
                )
            
            keys = kwargs.get("keys", "")
            if not keys:
                return TaskResult(False, "Keys are required (e.g., 'ctrl+c')", error="Missing keys")
            
            # Parse keys (can be string like "ctrl+c" or list like ["ctrl", "c"])
            if isinstance(keys, str):
                key_list = keys.lower().split("+")
            else:
                key_list = [str(k).lower() for k in keys]
            
            pyautogui.hotkey(*key_list)
            
            return TaskResult(
                True,
                f"Pressed hotkey: {'+'.join(key_list)}",
                data={"keys": key_list}
            )
        except Exception as e:
            logger.error(f"HotkeyTask error: {e}")
            return TaskResult(False, f"Failed to press hotkey: {str(e)}", error=str(e))


class FindImageTask(BaseTask):
    """Find an image on the screen"""
    
    def __init__(self):
        super().__init__(
            name="find_image",
            description="Find an image on the screen and return its location",
            requires_confirmation=False
        )
    
    def get_required_params(self) -> List[str]:
        return ["image_path"]
    
    def execute(self, **kwargs) -> TaskResult:
        try:
            try:
                import pyautogui
            except ImportError:
                return TaskResult(
                    False,
                    "pyautogui not installed. Install with: pip install pyautogui",
                    error="Module not found"
                )
            
            image_path = kwargs.get("image_path")
            if not image_path or not os.path.exists(image_path):
                return TaskResult(False, f"Image file not found: {image_path}", error="File not found")
            
            confidence = kwargs.get("confidence", 0.8)
            region = kwargs.get("region")  # Optional region to search
            
            if region and len(region) == 4:
                location = pyautogui.locateOnScreen(image_path, confidence=confidence, region=region)
            else:
                location = pyautogui.locateOnScreen(image_path, confidence=confidence)
            
            if location:
                center = pyautogui.center(location)
                return TaskResult(
                    True,
                    f"Found image at {center} (confidence: {confidence})",
                    data={
                        "x": center.x,
                        "y": center.y,
                        "left": location.left,
                        "top": location.top,
                        "width": location.width,
                        "height": location.height,
                        "confidence": confidence
                    }
                )
            else:
                return TaskResult(
                    False,
                    f"Image not found on screen (confidence: {confidence})",
                    error="Image not found"
                )
        except Exception as e:
            logger.error(f"FindImageTask error: {e}")
            return TaskResult(False, f"Failed to find image: {str(e)}", error=str(e))


class ScrollTask(BaseTask):
    """Scroll the screen"""
    
    def __init__(self):
        super().__init__(
            name="scroll",
            description="Scroll up or down on the screen",
            requires_confirmation=False
        )
    
    def execute(self, **kwargs) -> TaskResult:
        try:
            try:
                import pyautogui
            except ImportError:
                return TaskResult(
                    False,
                    "pyautogui not installed. Install with: pip install pyautogui",
                    error="Module not found"
                )
            
            clicks = kwargs.get("clicks", 3)  # Positive = scroll up, negative = scroll down
            x = kwargs.get("x")  # Optional x coordinate
            y = kwargs.get("y")  # Optional y coordinate
            
            if x is not None and y is not None:
                pyautogui.scroll(clicks, x=x, y=y)
            else:
                pyautogui.scroll(clicks)
            
            direction = "up" if clicks > 0 else "down"
            return TaskResult(
                True,
                f"Scrolled {direction} {abs(clicks)} clicks",
                data={"clicks": clicks, "direction": direction}
            )
        except Exception as e:
            logger.error(f"ScrollTask error: {e}")
            return TaskResult(False, f"Failed to scroll: {str(e)}", error=str(e))


class MoveMouseTask(BaseTask):
    """Move mouse to a specific location"""
    
    def __init__(self):
        super().__init__(
            name="move_mouse",
            description="Move mouse cursor to specific coordinates",
            requires_confirmation=False
        )
    
    def get_required_params(self) -> List[str]:
        return ["x", "y"]
    
    def execute(self, **kwargs) -> TaskResult:
        try:
            try:
                import pyautogui
            except ImportError:
                return TaskResult(
                    False,
                    "pyautogui not installed. Install with: pip install pyautogui",
                    error="Module not found"
                )
            
            x = int(kwargs.get("x"))
            y = int(kwargs.get("y"))
            duration = kwargs.get("duration", 0.5)  # Time to move in seconds
            
            pyautogui.moveTo(x, y, duration=duration)
            
            return TaskResult(
                True,
                f"Moved mouse to ({x}, {y})",
                data={"x": x, "y": y, "duration": duration}
            )
        except Exception as e:
            logger.error(f"MoveMouseTask error: {e}")
            return TaskResult(False, f"Failed to move mouse: {str(e)}", error=str(e))


class GetScreenSizeTask(BaseTask):
    """Get the screen size"""
    
    def __init__(self):
        super().__init__(
            name="get_screen_size",
            description="Get the screen resolution (width x height)",
            requires_confirmation=False
        )
    
    def execute(self, **kwargs) -> TaskResult:
        try:
            try:
                import pyautogui
            except ImportError:
                return TaskResult(
                    False,
                    "pyautogui not installed. Install with: pip install pyautogui",
                    error="Module not found"
                )
            
            width, height = pyautogui.size()
            
            return TaskResult(
                True,
                f"Screen size: {width}x{height}",
                data={"width": width, "height": height}
            )
        except Exception as e:
            logger.error(f"GetScreenSizeTask error: {e}")
            return TaskResult(False, f"Failed to get screen size: {str(e)}", error=str(e))


# =====================================================
# TASK REGISTRY
# =====================================================

class TaskRegistry:
    """Registry for all available tasks"""
    
    def __init__(self):
        self.tasks: Dict[str, BaseTask] = {}
        self.task_history: List[Dict] = []
        self.config_path = Path("lea_tasks_config.json")
        self.load_config()
    
    def register_task(self, task: BaseTask):
        """Register a task"""
        self.tasks[task.name] = task
        logger.info(f"Registered task: {task.name}")
    
    def get_task(self, task_name: str) -> Optional[BaseTask]:
        """Get a task by name"""
        return self.tasks.get(task_name)
    
    def list_tasks(self) -> List[Dict]:
        """List all available tasks"""
        return [
            {
                "name": task.name,
                "description": task.description,
                "requires_confirmation": task.requires_confirmation,
                "allowed": task.allowed,
                "required_params": task.get_required_params()
            }
            for task in self.tasks.values()
        ]
    
    def execute_task(self, task_name: str, params: Dict, confirmed: bool = False) -> TaskResult:
        """Execute a task"""
        task = self.get_task(task_name)
        
        if not task:
            return TaskResult(False, f"Task not found: {task_name}", error="Task not found")
        
        if not task.allowed:
            return TaskResult(False, f"Task is disabled: {task_name}", error="Task disabled")
        
        if task.requires_confirmation and not confirmed:
            return TaskResult(False, f"Task requires confirmation: {task_name}", error="Confirmation required")
        
        # Execute
        result = task.execute(**params)
        
        # Log to history
        self.task_history.append({
            "timestamp": datetime.now().isoformat(),
            "task_name": task_name,
            "params": params,
            "result": result.to_dict(),
            "confirmed": confirmed
        })
        
        # Save history (keep last 100)
        if len(self.task_history) > 100:
            self.task_history = self.task_history[-100:]
        
        self.save_config()
        
        return result
    
    def load_config(self):
        """Load task configuration"""
        if self.config_path.exists():
            try:
                with open(self.config_path, 'r') as f:
                    config = json.load(f)
                    # Apply config to tasks
                    for task_name, task_config in config.get("tasks", {}).items():
                        if task_name in self.tasks:
                            self.tasks[task_name].allowed = task_config.get("allowed", True)
            except Exception as e:
                logger.error(f"Error loading task config: {e}")
    
    def save_config(self):
        """Save task configuration"""
        try:
            config = {
                "tasks": {
                    name: {"allowed": task.allowed}
                    for name, task in self.tasks.items()
                },
                "history": self.task_history[-50:]  # Keep last 50
            }
            with open(self.config_path, 'w') as f:
                json.dump(config, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving task config: {e}")
    
    def enable_task(self, task_name: str):
        """Enable a task"""
        if task_name in self.tasks:
            self.tasks[task_name].allowed = True
            self.save_config()
    
    def disable_task(self, task_name: str):
        """Disable a task"""
        if task_name in self.tasks:
            self.tasks[task_name].allowed = False
            self.save_config()


# =====================================================
# INITIALIZE REGISTRY WITH BUILT-IN TASKS
# =====================================================

def create_task_registry() -> TaskRegistry:
    """Create and populate task registry"""
    registry = TaskRegistry()
    
    # Register all built-in tasks
    registry.register_task(FileCopyTask())
    registry.register_task(FileMoveTask())
    registry.register_task(FileDeleteTask())
    registry.register_task(FileReadTask())
    registry.register_task(FileWriteTask())
    registry.register_task(DirectoryCreateTask())
    registry.register_task(DirectoryListTask())
    registry.register_task(TextReplaceTask())
    registry.register_task(SystemCommandTask())
    
    # Register screen automation tasks
    registry.register_task(ScreenshotTask())
    registry.register_task(ClickTask())
    registry.register_task(TypeTask())
    registry.register_task(KeyPressTask())
    registry.register_task(HotkeyTask())
    registry.register_task(FindImageTask())
    registry.register_task(ScrollTask())
    registry.register_task(MoveMouseTask())
    registry.register_task(GetScreenSizeTask())
    
    # Try to register custom tasks (if file exists)
    try:
        # Try importing custom tasks module
        import importlib.util
        custom_tasks_path = Path(__file__).parent / "custom_tasks_example.py"
        
        if custom_tasks_path.exists():
            spec = importlib.util.spec_from_file_location("custom_tasks", custom_tasks_path)
            if spec and spec.loader:
                custom_tasks = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(custom_tasks)
                
                # Call register function if it exists
                if hasattr(custom_tasks, 'register_custom_tasks'):
                    custom_tasks.register_custom_tasks()
                    logging.info("Custom tasks loaded successfully")
    except Exception as e:
        # Custom tasks are optional, just log and continue
        logging.info(f"Custom tasks not loaded (this is OK): {e}")
    
    return registry


# Global registry instance
_task_registry = None

def get_task_registry() -> TaskRegistry:
    """Get or create the global task registry"""
    global _task_registry
    if _task_registry is None:
        _task_registry = create_task_registry()
    return _task_registry

