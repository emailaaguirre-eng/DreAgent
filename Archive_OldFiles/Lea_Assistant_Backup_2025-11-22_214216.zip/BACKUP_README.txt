# Lea Assistant Backup

This backup was created on 2025-11-22 21:42:16

## Files Included

### Main Application
- Lea_Visual_Code_v2.5.1a_ TTS.py - Main Lea application

### Required Modules
- model_registry.py - Model registry and capability mapping
- universal_file_reader.py - Universal file reading support
- lea_tasks.py - Task execution system

### Configuration
- lea_settings.json - User settings
- .env - **NOT INCLUDED** (contains sensitive API keys - create your own)

### Assets
- assets/ - Application icons and splash screens

## Setup Instructions

1. Extract this zip file to a directory
2. Install Python 3.8 or higher
3. Install required packages:
   ```
   pip install PyQt6 openai python-dotenv
   ```
4. Optional packages (for full functionality):
   ```
   pip install gtts pygame SpeechRecognition pyaudio Pillow
   ```
5. Create a .env file in the extracted directory with your API key:
   ```
   OPENAI_API_KEY=your_api_key_here
   ```
6. Run Lea:
   ```
   python "Lea_Visual_Code_v2.5.1a_ TTS.py"
   ```

## Features

- Multi-agent system with 7 specialized modes
- Model registry with automatic fallback
- Universal file reading
- Task execution system
- TTS (Text-to-Speech) support
- Speech recognition support
- Image analysis support

## Troubleshooting

If you encounter issues:
1. Check that all required Python packages are installed
2. Verify your .env file has a valid OPENAI_API_KEY
3. Check the console for error messages
4. See FIXES_SUMMARY.md for known issues and fixes

## Version

This backup includes fixes for:
- Mode switching crashes
- Model availability issues
- TTS feature blocking
- Unicode encoding errors

Backup created: 2025-11-22 21:42:16
