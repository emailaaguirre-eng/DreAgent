# Export and Download Workers (using PyQt6)
from PyQt6.QtCore import QObject, pyqtSignal, pyqtSlot
import sys
import os

class ExportWorker(QObject):
    finished = pyqtSignal(str)
    error = pyqtSignal(str)
    def __init__(self, path, mode, model, message_history, chat_text):
        super().__init__()
        self.path = path
        self.mode = mode
        self.model = model
        self.message_history = message_history
        self.chat_text = chat_text
    @pyqtSlot()
    def run(self):
        try:
            if not self.path:
                self.error.emit("No export path specified")
                return
            
            try:
                if self.path.endswith('.json'):
                    import json
                    data = {
                        'mode': str(self.mode) if self.mode else '',
                        'model': str(self.model) if self.model else '',
                        'history': self.message_history if isinstance(self.message_history, list) else []
                    }
                    with open(self.path, 'w', encoding='utf-8') as f:
                        json.dump(data, f, indent=2, ensure_ascii=False)
                else:
                    text_to_save = str(self.chat_text) if self.chat_text else ''
                    with open(self.path, 'w', encoding='utf-8') as f:
                        f.write(text_to_save)
                self.finished.emit(self.path)
            except PermissionError:
                self.error.emit(f"Permission denied: Cannot write to {self.path}")
            except OSError as os_err:
                self.error.emit(f"File system error: {str(os_err)}")
        except Exception as e:
            error_msg = f"Export error: {str(e)}"
            logging.error(f"ExportWorker error: {traceback.format_exc()}")
            self.error.emit(error_msg)

class SpeechRecognitionWorker(QObject):
    """Worker thread for speech recognition"""
    finished = pyqtSignal(str)  # Emits recognized text
    error = pyqtSignal(str)  # Emits error message
    listening = pyqtSignal()  # Emits when listening starts
    
    def __init__(self, recognizer, microphone_index=None):
        super().__init__()
        self.recognizer = recognizer
        self.microphone_index = microphone_index
    
    @pyqtSlot()
    def run(self):
        try:
            self.listening.emit()
            
            # Use default microphone or specified one
            with sr.Microphone(device_index=self.microphone_index) as source:
                # Adjust for ambient noise
                self.recognizer.adjust_for_ambient_noise(source, duration=0.5)
                
                # Listen for audio
                audio = self.recognizer.listen(source, timeout=5, phrase_time_limit=10)
            
            # Recognize speech using Google's service
            try:
                text = self.recognizer.recognize_google(audio)
                self.finished.emit(text)
            except sr.UnknownValueError:
                self.error.emit("Could not understand audio")
            except sr.RequestError as e:
                self.error.emit(f"Speech recognition error: {e}")
        except Exception as e:
            self.error.emit(f"Error: {str(e)}")

class DownloadWorker(QObject):
    finished = pyqtSignal(str, str)
    error = pyqtSignal(str)
    def __init__(self, last_response):
        super().__init__()
        self.last_response = last_response
    @pyqtSlot()
    def run(self):
        try:
            if not self.last_response:
                self.error.emit("No response content to download")
                return
            
            try:
                download_path = save_to_downloads(str(self.last_response), "lea_response.txt")
            except Exception as save_error:
                self.error.emit(f"Error saving file: {str(save_error)}")
                return
            
            try:
                basename = os.path.basename(download_path)
            except Exception:
                basename = "lea_response.txt"
            
            self.finished.emit(download_path, basename)
        except Exception as e:
            error_msg = f"Download error: {str(e)}"
            logging.error(f"DownloadWorker error: {traceback.format_exc()}")
            self.error.emit(error_msg)

### Lea - Complete Multi-Agent System ###

"""
Hummingbird – Lea
Multi-agent assistant with:
- All 7 specialized modes
- Knowledge base integration  
- Universal file reading
- Automatic backups with timestamps
- Download capability
"""

from dotenv import load_dotenv
load_dotenv()

import os
import html
import json
import shutil
import time
import hashlib
from pathlib import Path
from datetime import datetime
from typing import Optional, List, Dict, Any

import requests
from openai import OpenAI

# TTS imports
try:
    from gtts import gTTS
    import tempfile
    import pygame
    TTS_AVAILABLE = True
    PYGAME_AVAILABLE = True
except ImportError:
    TTS_AVAILABLE = False
    PYGAME_AVAILABLE = False
    print("TTS libraries not available. Install with: pip install gtts pygame")

# Speech Recognition imports
try:
    import speech_recognition as sr
    SPEECH_RECOGNITION_AVAILABLE = True
except ImportError:
    SPEECH_RECOGNITION_AVAILABLE = False
    print("Speech recognition not available. Install with: pip install SpeechRecognition")

from PyQt6.QtCore import Qt, pyqtSignal, QThread, QObject, pyqtSlot, QUrl
from PyQt6.QtGui import QIcon, QPixmap, QColor, QDragEnterEvent, QDragMoveEvent, QDropEvent, QTextCursor
from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QComboBox, QTextEdit, QLineEdit,
    QSizePolicy, QFrame, QSplashScreen, QFileDialog,
    QMessageBox, QCheckBox, QDialog, QTableWidget, QGroupBox, QDialogButtonBox,
    QTableWidgetItem, QHeaderView, QMenu,
    QListWidget, QListWidgetItem,
)

# =====================================================
# TIME-AWARE GREETINGS
# =====================================================

def get_greeting():
    """Get time-appropriate greeting based on current hour"""
    hour = datetime.now().hour
    
    if 5 <= hour < 12:
        return "Good morning"
    elif 12 <= hour < 17:
        return "Good afternoon"
    elif 17 <= hour < 22:
        return "Good evening"
    else:
        return "Hey there"  # Late night/early morning

def get_time_context():
    """Get additional context about the time of day"""
    hour = datetime.now().hour
    
    if 5 <= hour < 9:
        return "Hope you're having a great start to your day!"
    elif 9 <= hour < 12:
        return "Hope your morning is going well!"
    elif 12 <= hour < 14:
        return "Hope you're having a good lunch break!"
    elif 14 <= hour < 17:
        return "Hope your afternoon is productive!"
    elif 17 <= hour < 20:
        return "Hope you're wrapping up a good day!"
    elif 20 <= hour < 22:
        return "Hope you're winding down nicely!"
    else:
        return "Burning the midnight oil?"

# --- CRASH HANDLER (Global Exception Logger) ---
import logging
import traceback

CRASH_LOG = "lea_crash.log"

logging.basicConfig(
    filename=CRASH_LOG,
    level=logging.DEBUG,
    format="%(asctime)s %(levelname)s %(message)s"
)

def handle_exception(exc_type, exc_value, exc_tb):
    tb = "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
    logging.error("Uncaught exception:\n%s", tb)

    try:
        msg = QMessageBox()
        msg.setWindowTitle("Lea Error")
        msg.setText("An unexpected error occurred.\nDetails were saved to lea_crash.log.")
        msg.setDetailedText(tb)
        msg.setIcon(QMessageBox.Icon.Critical)
        msg.exec()
    except Exception:
        print("Error while showing message box:", traceback.format_exc())
        print(tb)

sys.excepthook = handle_exception
# --- END CRASH HANDLER ---


# Import universal file reader
try:
    from universal_file_reader import read_file
    FILE_READER_AVAILABLE = True
except ImportError:
    print("WARNING: universal_file_reader.py not found.")
    FILE_READER_AVAILABLE = False
    def read_file(path):
        return {'success': False, 'error': 'File reader not available'}

# Import task system
try:
    from lea_tasks import get_task_registry, TaskResult
    TASK_SYSTEM_AVAILABLE = True
    task_registry = get_task_registry()
except ImportError as e:
    print(f"WARNING: lea_tasks.py not found. Task system disabled: {e}")
    TASK_SYSTEM_AVAILABLE = False
    task_registry = None

# =====================================================
# OPENAI SETUP
# =====================================================

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
openai_client = OpenAI(api_key=OPENAI_API_KEY) if OPENAI_API_KEY else None

if not OPENAI_API_KEY:
    print("=" * 60)
    print("WARNING: 'OPENAI_API_KEY' not found in .env")
    print("=" * 60)

# =====================================================
# DIRECTORIES
# =====================================================

PROJECT_DIR = Path(__file__).resolve().parent
ASSETS_DIR = PROJECT_DIR / "assets"
BACKUPS_DIR = PROJECT_DIR / "backups"
DOWNLOADS_DIR = PROJECT_DIR / "downloads"

# Create directories
for dir_path in [BACKUPS_DIR, DOWNLOADS_DIR]:
    dir_path.mkdir(exist_ok=True)

SPLASH_FILE = ASSETS_DIR / "Hummingbird_LEA_v1_Splash_Logo_Lime_Green.png"
ICON_FILE = ASSETS_DIR / "Hummingbird_LEA_Logo_White_No BKGND.png"

print(f"\nDirectories created:")
print(f"  💾 Backups: {BACKUPS_DIR}")
print(f"  📥 Downloads: {DOWNLOADS_DIR}\n")

# =====================================================
# BACKUP SYSTEM
# =====================================================

def create_backup(file_path: Path) -> str:
    """Create timestamped backup in backups/ folder"""
    if not file_path.exists():
        return None
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_name = f"{file_path.stem}_{timestamp}{file_path.suffix}"
    backup_path = BACKUPS_DIR / backup_name
    
    shutil.copy2(file_path, backup_path)
    return str(backup_path)

def save_to_downloads(content: str, filename: str) -> str:
    """Save content to downloads/ folder with timestamp"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    name_parts = filename.rsplit('.', 1)
    
    if len(name_parts) == 2:
        filename = f"{name_parts[0]}_{timestamp}.{name_parts[1]}"
    else:
        filename = f"{filename}_{timestamp}.txt"
    
    download_path = DOWNLOADS_DIR / filename
    
    with open(download_path, 'w', encoding='utf-8') as f:
        f.write(content)
    
    return str(download_path)

# =====================================================
# LEGAL & INCENTIVES RESOURCES
# =====================================================

LEGAL_RESOURCES_TEXT = """
### Arizona Legal Resources
- Maricopa County Law Library: https://superiorcourt.maricopa.gov/llrc/
- Arizona Court Rules: https://govt.westlaw.com/azrules/
- Arizona Statutes: https://law.justia.com/arizona/
- Case Law: https://law.justia.com/cases/arizona/
- Clerk Self-Help: https://www.clerkofcourt.maricopa.gov/

**Quick Reference:**
- Service: Ariz. R. Civ. P. 4
- Default: Ariz. R. Civ. P. 55
- Relief from Judgment: Ariz. R. Civ. P. 60(b)(4)
"""

INCENTIVES_POLICY = """
### Incentives Research Framework
Research grants, tax credits, rebates, training funds for businesses.
Focus on: Federal (IRA, R&D credits), State (enterprise zones), Utility programs.
"""

# =====================================================
# CORE RULES & KNOWLEDGE CONTEXT
# =====================================================

CORE_RULES = """
### Core Principles
- Be honest about knowledge vs. inference
- Never fabricate sources or details
- Ask clarifying questions when needed
- Show your work on calculations
- Support Dre's decisions

### Your Personality - Lea's Character
You are Lea, Dre's personal assistant. Your personality is:

**Warm & Friendly**: 
- Always greet Dre with warmth and enthusiasm
- Use a conversational, approachable tone
- Show genuine care and interest in helping
- Remember details about Dre and reference them naturally

**Funny & Personable**:
- Use appropriate humor when fitting (not forced)
- Light jokes and playful comments are welcome
- Keep things engaging and enjoyable
- Don't be overly formal - be like a trusted friend

**Intelligent & Thoughtful**:
- Provide well-reasoned, insightful responses
- Think before answering, consider context
- Offer multiple perspectives when helpful
- Admit when you're uncertain and explain why

**Helpful & Proactive**:
- Anticipate needs when possible
- Offer solutions, not just information
- Break down complex topics clearly
- Suggest next steps when appropriate

**Mindful & Respectful**:
- Always remember Dre's preferences and constraints
- Respect boundaries and ask before making changes
- Consider the context of requests
- Be mindful of tone and appropriateness

**Communication Style**:
- Use "I" and "you" naturally (like we're chatting)
- Be enthusiastic but not overwhelming
- Balance professionalism with friendliness
- Use emojis sparingly but appropriately (🐦 for yourself, ✅ for success, etc.)

Remember: You're not just an assistant - you're Lea, Dre's trusted partner and friend.

### Web Search Capability
You have access to web search when you need current information.

**When to search the web:**
- Current events, news, or recent developments
- Information that changes frequently (prices, rates, statistics)
- Technical documentation or API updates
- Recent product releases or announcements
- Anything after your knowledge cutoff (April 2024)
- When explicitly asked to "search" or "look up"

**How to search:**
Use the format: [SEARCH: your search query here]

**Example:**
User: "What's the current price of Tesla stock?"
You: [SEARCH: Tesla stock price today]
Then use the results to answer.

**Don't search for:**
- General knowledge from before April 2024
- Programming concepts that haven't changed
- Historical facts
- Math or logic problems
- Information already provided in the conversation

### Agentic Task Execution
You have the ability to autonomously perform tasks using a structured format.
Remember to maintain your warm, friendly personality even when executing tasks!

**When to execute tasks:**
- When Dre explicitly asks you to perform a file operation, system command, or automated task
- When a monotonous task can be automated (file copying, text replacement, etc.)
- When Dre says "do this" or "perform this task"

**How to execute tasks:**
Use the format: [TASK: task_name] [PARAMS: param1=value1, param2=value2]

**Personality in task execution:**
- Announce what you're about to do in a friendly, helpful way
- Show enthusiasm when you can help save Dre time
- Celebrate successful task completions
- Be empathetic if a task fails, and offer alternatives
- Make automation feel like you're a helpful partner, not a robot

**Available tasks:**
- file_copy: Copy files (source, destination)
- file_move: Move files (source, destination) - requires confirmation
- file_delete: Delete files (path) - requires confirmation
- file_read: Read file contents (path)
- file_write: Write content to file (path, content)
- directory_create: Create directories (path)
- directory_list: List directory contents (path)
- text_replace: Replace text in file (path, old_text, new_text) - requires confirmation
- system_command: Execute system command (command) - requires confirmation and whitelist
- screenshot: Take a screenshot (save_path optional, region optional)
- click: Click at coordinates (x, y required; button, clicks, interval optional) - requires confirmation
- type: Type text at cursor (text required; interval optional) - requires confirmation
- key_press: Press a key (key required; presses, interval optional) - requires confirmation
- hotkey: Press key combination like "ctrl+c" (keys required) - requires confirmation
- find_image: Find an image on screen (image_path required; confidence, region optional)
- scroll: Scroll up/down (clicks required; x, y optional)
- move_mouse: Move mouse to coordinates (x, y required; duration optional)
- get_screen_size: Get screen resolution (no params)

Note: Additional custom tasks may be available. Check the Tasks dialog (🤖 Tasks button) to see all registered tasks.

**Examples:**
User: "Copy all .txt files from C:\\Temp to C:\\Backup"
You: [TASK: file_copy] [PARAMS: source=C:\\Temp\\*.txt, destination=C:\\Backup]

User: "Read the config.json file"
You: [TASK: file_read] [PARAMS: path=config.json]

User: "Create a folder called Projects"
You: [TASK: directory_create] [PARAMS: path=Projects]

User: "Take a screenshot and save it"
You: [TASK: screenshot] [PARAMS: save_path=screenshot.png]

User: "Click the button at coordinates 500, 300"
You: [TASK: click] [PARAMS: x=500, y=300]

User: "Type 'Hello World' into the current field"
You: [TASK: type] [PARAMS: text=Hello World]

User: "Press Ctrl+C to copy"
You: [TASK: hotkey] [PARAMS: keys=ctrl+c]

User: "Find the save icon on screen"
You: First take a screenshot, then use [TASK: find_image] [PARAMS: image_path=save_icon.png]

**Important:**
- Always confirm before executing tasks that require confirmation (move, delete, system_command)
- Never execute dangerous commands without explicit permission
- Show the user what task you're about to perform before executing
- Report the results of task execution clearly
"""

# =====================================================
# AGENT CONFIGURATIONS
# =====================================================

AGENTS = {
    "General Assistant & Triage": {
        "system_prompt": CORE_RULES + """
You are Lea, Dre's primary assistant and triage system.
You're the friendly, warm, and intelligent chief of staff who helps Dre with everything.
Your role is to:
- Be the first point of contact and make Dre feel welcome
- Route specialized requests to other modes when needed
- Handle general questions with warmth and helpfulness
- Keep things organized and running smoothly

When routing to other modes, explain why and make the transition smooth:
IT Support, Executive Assistant & Operations, Incentives & Client Forms,
Research & Learning, Legal Research & Drafting, Finance & Tax.

Always maintain your warm, friendly, and helpful personality - that's what makes you Lea!
"""
    },
    "IT Support": {
        "system_prompt": CORE_RULES + """
You are Lea, Dre's IT & technical support assistant.
You're the friendly tech expert who makes technology less intimidating.

Your expertise includes: Python, PowerShell, APIs, debugging, databases, automation.
When providing technical help:
- Break down complex concepts in a friendly, understandable way
- Provide complete runnable code with error handling and explanations
- Use analogies and examples to make things clear
- Celebrate small wins and make learning fun
- Don't be condescending - remember everyone starts somewhere

Keep that warm, helpful personality even when diving deep into technical details!
"""
    },
    "Executive Assistant & Operations": {
        "system_prompt": CORE_RULES + """
You are Lea, Dre's Executive Assistant.
You're the organized, friendly, and efficient partner who helps Dre stay on top of everything.

Help with: professional emails, presentations, task organization,
scheduling, workplace communication, professional development.

**Screen Automation Capabilities:**
You have powerful screen automation abilities that allow you to perform tasks on Dre's computer:
- Take screenshots to see what's on screen
- Click buttons, links, and UI elements
- Type text into fields and forms
- Press keys and hotkeys (Ctrl+C, Alt+Tab, etc.)
- Find images/icons on screen and interact with them
- Scroll pages and windows
- Move the mouse cursor
- Get screen dimensions

**When to use screen automation:**
- When Dre asks you to "click this button" or "fill out this form"
- When automating repetitive tasks across applications
- When interacting with software that doesn't have APIs
- When helping with data entry or form completion
- When navigating applications or websites

**Screen automation tasks available:**
- screenshot: Take a screenshot (save_path optional, region optional)
- click: Click at coordinates (x, y required; button, clicks, interval optional)
- type: Type text at cursor (text required; interval optional)
- key_press: Press a key (key required; presses, interval optional)
- hotkey: Press key combination like "ctrl+c" (keys required)
- find_image: Find an image on screen (image_path required; confidence, region optional)
- scroll: Scroll up/down (clicks required, positive=up, negative=down; x, y optional)
- move_mouse: Move mouse to coordinates (x, y required; duration optional)
- get_screen_size: Get screen resolution (no params)

**Important safety notes:**
- Click, type, key_press, and hotkey tasks require confirmation for safety
- Always take a screenshot first to see what's on screen before clicking
- Use find_image to locate buttons/icons before clicking them
- Be careful with coordinates - verify screen size first if needed
- Test with small actions before automating large workflows

When assisting:
- Be warm and personable even in professional contexts
- Make organization and productivity feel manageable (not overwhelming)
- Suggest time-saving strategies with enthusiasm
- Help Dre sound professional while staying authentic
- Keep track of details so Dre doesn't have to stress
- Use screen automation to save Dre time on repetitive tasks

Your friendly personality helps make work feel less like work!
"""
    },
    "Incentives & Client Forms": {
        "system_prompt": CORE_RULES + INCENTIVES_POLICY + """
You are Lea, Dre's Incentives research assistant for EIAG.
You're the enthusiastic helper who makes finding opportunities exciting!

Research grants, credits, rebates. Connect to client forms and tools.

When researching:
- Present opportunities with genuine excitement when you find good matches
- Break down complex requirements into clear, actionable steps
- Make the research process feel like treasure hunting (but professional!)
- Help navigate forms and requirements with patience and clarity
- Celebrate when you find great opportunities for Dre

Your warm, helpful personality makes even bureaucratic processes more pleasant!
"""
    },
    "Research & Learning": {
        "system_prompt": CORE_RULES + """
You are Lea, Dre's Research & Learning assistant.
You're the curious, enthusiastic teacher who makes learning enjoyable!

When helping Dre learn:
- Break down complex topics step-by-step in plain language
- Summarize materials and explain concepts clearly
- Use analogies, examples, and stories to make things stick
- Show genuine enthusiasm about interesting topics
- Ask questions that help Dre think deeper
- Celebrate "aha!" moments and learning breakthroughs

Make learning feel like an adventure with a knowledgeable friend!
"""
    },
    "Legal Research & Drafting": {
        "system_prompt": CORE_RULES + LEGAL_RESOURCES_TEXT + """
You are Lea, Dre's Legal Research assistant for Arizona civil matters.
You're the helpful, organized assistant who makes legal research less intimidating.

### Arizona Legal Research & Paralegal Mode

In this mode you are an AI **paralegal-style legal research assistant** for Dre.

Your job:
- Find **actual, current statutes, rules, and cases** from authoritative sources.
- Provide **factual summaries** of:
  - what the rule says,
  - how the court interpreted it,
  - what patterns appear across multiple cases.
- Help Dre understand **how courts have responded in specific situations**, so she can decide what direction to take.

**Important:** You are NOT an attorney and do NOT give legal advice or predictions. Always remind Dre warmly: "I am not a lawyer, this is not legal advice."

### Zero-Hallucination Rule for Law

You MUST NOT invent:
- Statute numbers or rule numbers
- Case names, years, or quotes
- Holdings that you cannot tie to a real case or rule

If you cannot find solid authority, you MUST say so clearly using preferred language:
- "I could not find any Arizona cases directly on point."
- "I did not find clear authority addressing this exact fact pattern."
- "I am uncertain about this point; you should check with an attorney or a legal database."

It is ALWAYS better to say "I don't know" than to provide a guessed or inaccurate legal answer.
If something is uncertain, say explicitly that it is uncertain.

### How to Interpret Rules and Cases

For EACH important point of law:

1. **Locate authority first**
   - Find the relevant:
     - Arizona statutes (A.R.S.),
     - Rules (e.g., Ariz. R. Civ. P., Probate Rules, Justice Court Rules),
     - Cases interpreting those statutes/rules.

2. **Summarize the text**
   - Briefly explain, in plain English, what the statute or rule actually says.

3. **Describe how courts applied it**
   For each key case:
   - Identify the rule or statute at issue.
   - Summarize the facts at a high level.
   - State how the court interpreted the rule:
     - "In [Case Name], the court interpreted Rule ___ to mean that…"
     - "The court applied the rule by focusing on factors A, B, C."

4. **Extract the overall pattern**
   - After reviewing multiple authorities, you may state:
     - "Overall, Arizona courts have interpreted Rule ___ to mean that…"
   - This must be based on the actual cases you described, not your personal opinion.

5. **Separate fact from your analysis**
   - Clearly distinguish:
     - What the rule/case *says*,
     - What the court *did*,
     - Your **summary of the pattern** across cases.

### Standard Format for Legal Answers

For any Arizona legal research question, respond in this structure:

1. **Authorities Found**
   - List the key statutes, rules, and cases (with names and citations).

2. **What the Rule/Text Says**
   - Summarize the important language in plain English.

3. **How Courts Interpreted It**
   - For each key case:
     - Brief facts,
     - What issue the court decided,
     - How it interpreted the rule/statute.

4. **Overall Pattern / Interpretation**
   - Explain the pattern:
     - "Across these cases, courts have generally treated Rule ___ as meaning that…"
   - If the pattern is weak or mixed, say that clearly.

5. **Relation to Dre's Situation (Careful)**
   - Compare Dre's facts to the cases.
   - Use cautious language:
     - "These facts support an argument that…"
     - "This looks similar/different from [Case] because…"
   - Do NOT make promises or give strategic instructions.

6. **Uncertainty & Verification**
   - If anything is unclear or authority is thin, say so explicitly.
   - End with: "This is research and drafting assistance based on published sources, not legal advice. Please verify key authorities and consider consulting an attorney."

### General Guidelines

When helping with legal matters:
- Make complex legal concepts accessible and understandable
- Organize information clearly and logically
- Be thorough but not overwhelming
- Show empathy for the stress legal matters can cause
- Help Dre feel more informed and prepared

Your warm, helpful personality makes navigating legal complexity less daunting!
"""
    },
    "Finance & Tax": {
        "system_prompt": CORE_RULES + """
You are Lea, Dre's Finance & Tax assistant.
You're the organized, friendly helper who makes finances feel manageable!

Help organize tax docs and explain IRS/state guidance in plain English.

When helping with finances:
- Make financial concepts clear and understandable
- Help organize documents and information systematically
- Explain tax rules and requirements in plain English
- Show empathy for how stressful finances can be
- Use official sources and be accurate
- NOT a CPA - cannot give tax advice (remind Dre warmly, not dismissively)

Your warm, helpful personality makes even tax season a bit more bearable!
"""
    },
}

# CHAT MODELS - For conversational responses (standard chat completions)
# Ordered by capability: most capable first, then by speed/cost
MODEL_OPTIONS = {
    # Latest GPT-5.1 series (best for coding and agentic tasks)
    "GPT-5.1": "gpt-5.1-2025-11-13",  # Best model for coding and agentic tasks with configurable reasoning
    "GPT-5.1 Codex": "gpt-5.1-codex",  # Optimized for agentic coding in Codex
    "GPT-5.1 Codex Mini": "gpt-5.1-codex-mini",  # Smaller, cost-effective version for coding
    
    # GPT-5 series (previous generation, still excellent)
    "GPT-5": "gpt-5-2025-08-07",  # Intelligent reasoning model for coding and agentic tasks
    "GPT-5 Codex": "gpt-5-codex",  # Optimized for agentic coding
    "GPT-5 Mini": "gpt-5-mini-2025-08-07",  # Faster, cost-efficient version
    "GPT-5 Nano": "gpt-5-nano-2025-08-07",  # Fastest, most cost-efficient
    
    # GPT-4.1 series (smartest non-reasoning models)
    "GPT-4.1": "gpt-4.1",  # Smartest non-reasoning model
    "GPT-4.1 Mini": "gpt-4.1-mini",  # Smaller, faster version
    "GPT-4.1 Nano": "gpt-4.1-nano",  # Fastest, most cost-efficient
    
    # GPT-4o series (fast and capable)
    "GPT-4o": "gpt-4o",  # Best general purpose - fast and capable
    "GPT-4o Mini": "gpt-4o-mini",  # Fast and efficient - for simple tasks
    
    # Legacy models (still available)
    "GPT-4 Turbo": "gpt-4-turbo",  # Previous generation high-intelligence model
    "GPT-4": "gpt-4",  # Older high-intelligence model
    "GPT-3.5 Turbo": "gpt-3.5-turbo",  # Fast and economical - for basic tasks
}

# Default model per mode - optimized for effectiveness per use case
# Based on OpenAI model capabilities and each mode's specific requirements
DEFAULT_MODEL_PER_MODE = {
    "General Assistant & Triage": "GPT-5 Nano",  # Fast routing and simple questions - fastest response
    "IT Support": "GPT-5.1 Codex",  # Best for coding tasks - optimized for technical support
    "Executive Assistant & Operations": "GPT-5.1",  # Strong instruction following for task management and automation
    "Incentives & Client Forms": "GPT-4.1",  # Better research and information synthesis - smartest non-reasoning
    "Research & Learning": "GPT-5.1",  # Superior reasoning for complex topic explanations and learning
    "Legal Research & Drafting": "GPT-5.1",  # Maximum accuracy and reasoning - critical for legal work
    "Finance & Tax": "GPT-4.1",  # Better accuracy and careful analysis for financial matters
}


# =====================================================
# CHAT INPUT
# =====================================================

class ChatInputBox(QTextEdit):
    returnPressed = pyqtSignal()
    fileDropped = pyqtSignal(str)  # Emit file path when file is dropped
    
    def __init__(self, parent=None):
        super().__init__(parent)
        # Enable drag and drop
        self.setAcceptDrops(True)
        # Enable paste (Ctrl+V works by default, but ensure it's enabled)
        # Accept plain text paste to preserve formatting for code snippets
        self.setAcceptRichText(False)  # Plain text paste preserves code formatting better
    
    def insertFromMimeData(self, source):
        """Handle paste from clipboard - allows pasting text snippets"""
        if source.hasText():
            text = source.text()
            if text:
                cursor = self.textCursor()
                cursor.insertText(text)
                self.setTextCursor(cursor)
        elif source.hasUrls():
            # Handle file paste
            urls = source.urls()
            for url in urls:
                local_path = url.toLocalFile()
                if local_path and Path(local_path).exists():
                    self.fileDropped.emit(local_path)
        else:
            # Fall back to default behavior
            super().insertFromMimeData(source)
    
    def keyPressEvent(self, event):
        if event.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            if event.modifiers() & Qt.KeyboardModifier.ShiftModifier:
                super().keyPressEvent(event)
            else:
                self.returnPressed.emit()
        else:
            super().keyPressEvent(event)
    
    def dragEnterEvent(self, event: QDragEnterEvent):
        """Handle drag enter event - accept if files or text are being dragged"""
        if event.mimeData().hasUrls():
            # Accept file drops
            event.acceptProposedAction()
        elif event.mimeData().hasText():
            # Accept text drops
            event.acceptProposedAction()
        else:
            event.ignore()
    
    def dragMoveEvent(self, event: QDragMoveEvent):
        """Handle drag move event - accept if files or text"""
        if event.mimeData().hasUrls() or event.mimeData().hasText():
            event.acceptProposedAction()
        else:
            event.ignore()
    
    def dropEvent(self, event: QDropEvent):
        """Handle drop event - insert text or handle file drop"""
        if event.mimeData().hasUrls():
            # Handle file drop
            urls = event.mimeData().urls()
            file_paths = []
            
            for url in urls:
                # Convert QUrl to local file path
                local_path = url.toLocalFile()
                if local_path and Path(local_path).exists():
                    file_paths.append(local_path)
            
            if file_paths:
                # Emit signal for each file (or handle multiple files)
                for file_path in file_paths:
                    self.fileDropped.emit(file_path)
                event.acceptProposedAction()
                return
        
        if event.mimeData().hasText():
            # Handle text drop/paste
            text = event.mimeData().text()
            if text:
                # Insert text at cursor position
                cursor = self.textCursor()
                cursor.insertText(text)
                self.setTextCursor(cursor)
                event.acceptProposedAction()
                return
        
        event.ignore()

from typing import Optional

# =====================================================
# VECTOR MEMORY SYSTEM
# =====================================================

class LeaMemory:
    """Simple vector memory system using embeddings for conversation context"""
    
    def __init__(self, memory_dir: Path = None):
        self.memory_dir = memory_dir or (PROJECT_DIR / "memory")
        self.memory_dir.mkdir(exist_ok=True)
        self.memory_file = self.memory_dir / "conversation_memory.json"
        self.memories = self._load_memories()
        self.openai_client = None  # Will be set when needed
    
    def _load_memories(self) -> List[Dict]:
        """Load stored memories"""
        if self.memory_file.exists():
            try:
                with open(self.memory_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                logging.warning(f"Error loading memories: {e}")
                return []
        return []
    
    def _save_memories(self):
        """Save memories to disk"""
        try:
            with open(self.memory_file, 'w', encoding='utf-8') as f:
                json.dump(self.memories, f, indent=2, ensure_ascii=False)
        except Exception as e:
            logging.warning(f"Error saving memories: {e}")
    
    def set_client(self, openai_client):
        """Set OpenAI client for embeddings"""
        self.openai_client = openai_client
    
    def store_important_info(self, text: str, metadata: Dict = None):
        """Store important information from conversation"""
        if not self.openai_client:
            return
        
        try:
            # Create embedding for the text
            response = self.openai_client.embeddings.create(
                model="text-embedding-3-small",
                input=text[:1000]  # Limit length
            )
            embedding = response.data[0].embedding
            
            memory_entry = {
                "text": text,
                "embedding": embedding,
                "metadata": metadata or {},
                "timestamp": datetime.now().isoformat()
            }
            
            self.memories.append(memory_entry)
            # Keep only last 100 memories
            if len(self.memories) > 100:
                self.memories = self.memories[-100:]
            
            self._save_memories()
        except Exception as e:
            logging.warning(f"Error storing memory: {e}")
    
    def get_relevant_memories(self, query: str, k: int = 3) -> List[str]:
        """Retrieve relevant memories using cosine similarity"""
        if not self.openai_client or not self.memories:
            return []
        
        try:
            # Get embedding for query
            response = self.openai_client.embeddings.create(
                model="text-embedding-3-small",
                input=query[:1000]
            )
            query_embedding = response.data[0].embedding
            
            # Calculate cosine similarity
            similarities = []
            for memory in self.memories:
                mem_embedding = memory.get("embedding", [])
                if not mem_embedding:
                    continue
                
                # Cosine similarity
                dot_product = sum(a * b for a, b in zip(query_embedding, mem_embedding))
                magnitude_a = sum(a * a for a in query_embedding) ** 0.5
                magnitude_b = sum(b * b for b in mem_embedding) ** 0.5
                
                if magnitude_a > 0 and magnitude_b > 0:
                    similarity = dot_product / (magnitude_a * magnitude_b)
                    similarities.append((similarity, memory["text"]))
            
            # Sort by similarity and return top k
            similarities.sort(reverse=True, key=lambda x: x[0])
            return [text for _, text in similarities[:k]]
        except Exception as e:
            logging.warning(f"Error retrieving memories: {e}")
            return []

# =====================================================
# RETRY LOGIC WITH EXPONENTIAL BACKOFF
# =====================================================

def retry_api_call(func, max_attempts: int = 3, base_delay: float = 1.0):
    """Retry API calls with exponential backoff and rate limit handling"""
    for attempt in range(max_attempts):
        try:
            return func()
        except Exception as e:
            error_msg = str(e).lower()
            error_type = type(e).__name__
            
            # Don't retry on authentication errors
            if "401" in error_msg or "403" in error_msg or "authentication" in error_msg:
                raise
            
            # Don't retry on invalid model errors
            if "invalid" in error_msg and "model" in error_msg:
                raise
            
            # Retry on rate limits and timeouts
            if attempt < max_attempts - 1:
                if "rate_limit" in error_msg or "429" in error_msg or "too many requests" in error_msg:
                    # Try to extract rate limit reset time from exception
                    wait_time = None
                    
                    # Check if exception has response attribute (httpx.HTTPStatusError or OpenAI SDK wrapper)
                    response_obj = None
                    if hasattr(e, 'response'):
                        response_obj = e.response
                    elif hasattr(e, '_response'):  # OpenAI SDK might use _response
                        response_obj = e._response
                    
                    if response_obj and hasattr(response_obj, 'headers'):
                        headers = response_obj.headers
                        # Try to get reset time from headers
                        reset_requests = headers.get('x-ratelimit-reset-requests', '')
                        reset_tokens = headers.get('x-ratelimit-reset-tokens', '')
                        
                        # Parse reset times (format: "120ms" or "17.787s")
                        for reset_header in [reset_requests, reset_tokens]:
                            if reset_header:
                                try:
                                    if isinstance(reset_header, str):
                                        if reset_header.endswith('ms'):
                                            wait_time = float(reset_header[:-2]) / 1000.0
                                        elif reset_header.endswith('s'):
                                            wait_time = float(reset_header[:-1])
                                    if wait_time:
                                        # Add small buffer (10% or minimum 0.1s)
                                        wait_time = max(wait_time * 1.1, wait_time + 0.1)
                                        break
                                except (ValueError, AttributeError, TypeError):
                                    pass
                    
                    # If we couldn't parse reset time, use exponential backoff with minimum
                    if wait_time is None:
                        # For 429 errors, use longer initial delay
                        wait_time = max(base_delay * (2 ** attempt), 2.0)  # Minimum 2 seconds
                    else:
                        # Ensure minimum wait time of 0.5 seconds even if API says less
                        wait_time = max(wait_time, 0.5)
                    
                    logging.info(f"Rate limited (429), waiting {wait_time:.2f}s before retry (attempt {attempt + 1}/{max_attempts})")
                    time.sleep(wait_time)
                elif "timeout" in error_msg:
                    delay = base_delay * (1.5 ** attempt)
                    logging.info(f"Timeout, retrying in {delay:.1f}s (attempt {attempt + 1}/{max_attempts})")
                    time.sleep(delay)
                else:
                    # For other errors, shorter delay
                    delay = base_delay * (1.2 ** attempt)
                    logging.info(f"Error occurred, retrying in {delay:.1f}s (attempt {attempt + 1}/{max_attempts})")
                    time.sleep(delay)
            else:
                # Last attempt failed
                raise
    return None

# =====================================================
# WORKER THREADS
# =====================================================
class FileUploadWorker(QObject):
    finished = pyqtSignal(dict, str, str)  # result, backup_path, file_name
    error = pyqtSignal(str)

    def __init__(self, path: str):
        super().__init__()
        self.path = path

    @pyqtSlot()
    def run(self):
        try:
            if not self.path or not os.path.exists(self.path):
                self.error.emit(f"File not found: {self.path}")
                return
            
            # Use universal_file_reader if available
            try:
                from universal_file_reader import read_file
                result = read_file(self.path)
                if not isinstance(result, dict) or 'success' not in result:
                    self.error.emit("Invalid response from file reader")
                    return
            except ImportError:
                self.error.emit("File reader module not available")
                return
            except Exception as read_error:
                self.error.emit(f"Error reading file: {str(read_error)}")
                return
            
            backup_path = None
            if result.get('success'):
                try:
                    backup_path = create_backup(Path(self.path))
                except Exception as backup_error:
                    logging.warning(f"Backup failed: {backup_error}")
                    # Continue even if backup fails
            
            try:
                file_name = os.path.basename(self.path)
            except Exception:
                file_name = "unknown"
            
            self.finished.emit(result, backup_path, file_name)
        except Exception as e:
            error_msg = f"File upload error: {str(e)}"
            logging.error(f"FileUploadWorker error: {traceback.format_exc()}")
            self.error.emit(error_msg)

class LeaWorker(QObject):
    finished = pyqtSignal(str, str)  # answer, status
    error = pyqtSignal(str)
    stream_chunk = pyqtSignal(str)  # Streaming response chunks
    memory_context = pyqtSignal(str)  # Relevant memories found

    def __init__(self, openai_client, model_options, agents, mode, model, message_history, file_content, user_text, memory_system=None):
        super().__init__()
        self.openai_client = openai_client
        self.model_options = model_options
        self.agents = agents
        self.mode = mode
        self.model = model
        self.message_history = message_history
        self.file_content = file_content
        self.user_text = user_text
        self.memory_system = memory_system
        self.enable_streaming = True  # Can be made configurable

    @pyqtSlot()
    def run(self):
        try:
            # Validate inputs
            if not self.openai_client:
                self.error.emit("OpenAI client not initialized. Check your API key.")
                return
            
            if not self.user_text or not self.user_text.strip():
                self.error.emit("Empty message cannot be sent.")
                return
            
            if self.mode not in self.agents:
                self.error.emit(f"Invalid mode: {self.mode}")
                return
            
            if self.model not in self.model_options:
                self.error.emit(f"Invalid model: {self.model}")
                return
            
            # Build prompt safely
            parts = []
            if self.file_content:
                try:
                    file_content = str(self.file_content)[:100000]  # Ensure string and limit size
                    if len(self.file_content) > 100000:
                        parts.append(f"=== UPLOADED FILE (truncated to 100k chars) ===\n{file_content}\n=== END FILE ===\n")
                    else:
                        parts.append(f"=== UPLOADED FILE ===\n{file_content}\n=== END FILE ===\n")
                except Exception as e:
                    self.error.emit(f"Error processing file content: {str(e)}")
                    return
            
            parts.append(f"Dre's question:\n{str(self.user_text)}")
            full_prompt = "\n".join(parts)
            
            # Check token limits
            estimated_tokens = len(full_prompt) // 4
            if estimated_tokens > 25000:
                self.error.emit(f"Message too large (~{estimated_tokens:,} tokens). Please use a smaller file or uncheck 'Include uploaded file'")
                return
            
            # Append to history safely
            if not isinstance(self.message_history, list):
                self.message_history = []
            
            self.message_history.append({"role": "user", "content": full_prompt})
            # Limit history to configured max
            if len(self.message_history) > self.max_history_messages:
                self.message_history = self.message_history[-self.max_history_messages:]
            
            # Get system prompt with dynamic greeting
            base_system_prompt = self.agents[self.mode].get("system_prompt", "")
            # Add current time context
            greeting = get_greeting()
            time_context = get_time_context()
            current_time = datetime.now()
            time_str = current_time.strftime('%I:%M %p on %A, %B %d, %Y')
            date_str = current_time.strftime('%Y-%m-%d')
            system_prompt = f"""{base_system_prompt}

### Current Context
{greeting}, Dre! {time_context}

**Current Date and Time:**
- Date: {date_str}
- Time: {time_str}
- Day of Week: {current_time.strftime('%A')}
- Full: {time_str}

You have access to the current date and time. Use this information when Dre asks about time-sensitive matters, deadlines, or scheduling."""
            # Get relevant memories if memory system is available
            relevant_memories = []
            if self.memory_system and self.memory_system.openai_client:
                try:
                    relevant_memories = self.memory_system.get_relevant_memories(self.user_text, k=3)
                    if relevant_memories:
                        memory_context = "\n=== Relevant Previous Context ===\n" + "\n".join(relevant_memories) + "\n=== End Context ===\n"
                        self.memory_context.emit(f"Found {len(relevant_memories)} relevant memories")
                        # Add to system prompt
                        system_prompt += f"\n\n{memory_context}"
                except Exception as mem_error:
                    logging.warning(f"Error retrieving memories: {mem_error}")
            
            messages = [{"role": "system", "content": system_prompt}] + self.message_history
            
            # Define functions for task execution (replaces regex parsing)
            functions = []
            if TASK_SYSTEM_AVAILABLE and task_registry:
                # Build function definitions from available tasks
                available_tasks = task_registry.list_tasks()
                for task_info in available_tasks:
                    if task_info.get("allowed", True):  # Only include enabled tasks
                        task_name = task_info["name"]
                        task_desc = task_info.get("description", f"Execute {task_name} task")
                        
                        # Build parameters schema (simplified - you can enhance this)
                        properties = {}
                        required = []
                        
                        # Common parameters that tasks might use
                        common_params = ["source", "destination", "path", "content", "old_text", "new_text", "command", "directory"]
                        for param in common_params:
                            properties[param] = {"type": "string", "description": f"{param} parameter for {task_name}"}
                        
                        functions.append({
                            "name": f"execute_task_{task_name}",
                            "description": task_desc,
                            "parameters": {
                                "type": "object",
                                "properties": {
                                    "task_name": {"type": "string", "description": f"The task name: {task_name}"},
                                    "params": {
                                        "type": "object",
                                        "properties": properties,
                                        "description": "Task-specific parameters"
                                    }
                                },
                                "required": ["task_name", "params"]
                            }
                        })
            
            # Make API call with streaming, retry logic, and function calling
            model_name = self.model_options[self.model]
            answer = ""
            
            def make_api_call():
                """Inner function for retry logic"""
                nonlocal answer
                
                # Chat models use standard parameters
                api_params = {
                    "model": model_name,
                    "messages": messages,
                    "max_tokens": 4096,  # Standard limit for chat
                    "timeout": 60.0
                }
                
                # Some models (like GPT-5, GPT-5.1, o1, o3, o4) may have different temperature requirements
                # Only set temperature for models that support custom values
                # Models that require default temperature: gpt-5*, o1-*, o3-*, o4-*
                model_lower = model_name.lower()
                if not (model_lower.startswith("gpt-5") or model_lower.startswith("o1-") or 
                        model_lower.startswith("o3-") or model_lower.startswith("o4-")):
                    api_params["temperature"] = 0.7
                
                if self.enable_streaming:
                    api_params["stream"] = True
                else:
                    api_params["stream"] = False
                
                if functions:
                    api_params["functions"] = functions
                    api_params["function_call"] = "auto"
                
                if api_params.get("stream"):
                    # Streaming response
                    stream = self.openai_client.chat.completions.create(**api_params)
                    
                    full_response = ""
                    function_calls = []
                    
                    for chunk in stream:
                        if chunk.choices[0].delta.content:
                            content = chunk.choices[0].delta.content
                            full_response += content
                            self.stream_chunk.emit(content)
                        
                        # Handle function calls in streaming
                        if chunk.choices[0].delta.function_call:
                            func_call = chunk.choices[0].delta.function_call
                            if func_call.name:
                                function_calls.append({
                                    "name": func_call.name,
                                    "arguments": func_call.arguments or ""
                                })
                    
                    answer = full_response
                    
                    # Handle function calls
                    if function_calls and TASK_SYSTEM_AVAILABLE:
                        answer = self._handle_function_calls(function_calls, answer)
                    
                    return answer
                else:
                    # Non-streaming response
                    # Remove stream parameter if present
                    if "stream" in api_params:
                        del api_params["stream"]
                    response = self.openai_client.chat.completions.create(**api_params)
                    
                    if not response or not response.choices:
                        raise Exception("Invalid response from OpenAI API")
                    
                    # Check for function calls
                    message = response.choices[0].message
                    if message.function_call and TASK_SYSTEM_AVAILABLE:
                        function_calls = [{
                            "name": message.function_call.name,
                            "arguments": message.function_call.arguments
                        }]
                        answer = message.content or ""
                        answer = self._handle_function_calls(function_calls, answer)
                    else:
                        answer = message.content or ""
                    
                    if not answer:
                        raise Exception("Empty response from OpenAI API")
                    
                    return answer
            
            # Use retry logic
            try:
                answer = retry_api_call(make_api_call, max_attempts=3, base_delay=1.0)
            except Exception as api_error:
                error_msg = str(api_error)
                # Provide user-friendly error messages
                if "rate_limit" in error_msg.lower() or "429" in error_msg or "too many requests" in error_msg.lower():
                    # Check if we can get more details from the exception
                    wait_suggestion = ""
                    response_obj = None
                    if hasattr(api_error, 'response'):
                        response_obj = api_error.response
                    elif hasattr(api_error, '_response'):  # OpenAI SDK might use _response
                        response_obj = api_error._response
                    
                    if response_obj and hasattr(response_obj, 'headers'):
                        headers = response_obj.headers
                        reset_requests = headers.get('x-ratelimit-reset-requests', '')
                        if reset_requests:
                            wait_suggestion = f" (Rate limit resets in {reset_requests})"
                    self.error.emit(f"API rate limit exceeded. The system tried 3 times but still hit the limit.{wait_suggestion}\n\nPlease wait a moment and try again.")
                elif "timeout" in error_msg.lower():
                    self.error.emit("Request timed out. The system tried 3 times. Please try again.")
                elif "authentication" in error_msg.lower() or "401" in error_msg or "403" in error_msg:
                    self.error.emit("Authentication failed. Check your OpenAI API key in your .env file.")
                elif "invalid" in error_msg.lower() and "model" in error_msg.lower():
                    self.error.emit(f"Invalid model: {model_name}. Please select a different model.")
                else:
                    self.error.emit(f"API Error: {error_msg}")
                return
            
            # Web search handling (optional, can be improved)
            # Note: This is kept for backward compatibility, but function calling is preferred
            if "[SEARCH:" in answer and "]" in answer:
                try:
                    import re
                    search_pattern = r'\[SEARCH:\s*([^\]]+)\]'
                    searches = re.findall(search_pattern, answer)
                    if searches:
                        all_results = []
                        for query in searches:
                            # Dummy search result (replace with real web_search if available)
                            all_results.append(f"=== Search Results for '{query}' ===\n(Dummy search results)\n")
                        search_context = "\n".join(all_results)
                        followup_prompt = f"{search_context}\n\nNow answer Dre's original question using these search results."
                        self.message_history.append({"role": "user", "content": followup_prompt})
                        
                        # Limit history again
                        if len(self.message_history) > 20:
                            self.message_history = self.message_history[-20:]
                        
                        messages = [{"role": "system", "content": system_prompt}] + self.message_history
                        
                        # Second API call for search results
                        try:
                            response = self.openai_client.chat.completions.create(
                                model=model_name,
                                messages=messages,
                                timeout=60.0
                            )
                            if response and response.choices:
                                answer = response.choices[0].message.content or answer
                        except Exception as search_error:
                            # If search follow-up fails, use original answer
                            logging.warning(f"Search follow-up failed: {search_error}")
                            pass
                except Exception as search_parse_error:
                    logging.warning(f"Search parsing failed: {search_parse_error}")
                    # Continue with original answer
            
            # Ensure answer is a string and not empty
            if not answer:
                answer = ""
            answer = str(answer).strip()
            
            # Store important information in memory
            if self.memory_system and self.memory_system.openai_client and answer:
                try:
                    # Store the answer if it seems important (you can enhance this logic)
                    if len(answer) > 100:  # Only store substantial responses
                        self.memory_system.store_important_info(
                            f"User asked: {self.user_text}\nLea responded: {answer[:500]}",
                            metadata={"mode": self.mode, "timestamp": datetime.now().isoformat()}
                        )
                except Exception as mem_store_error:
                    logging.warning(f"Error storing memory: {mem_store_error}")
            
            # Save to history - CRITICAL: Always save assistant responses
            if answer:  # Only save if there's actually content
                self.message_history.append({"role": "assistant", "content": answer})
                # Limit history to last 20 messages
                if len(self.message_history) > 20:
                    self.message_history = self.message_history[-20:]
            else:
                logging.warning("Empty answer received, not saving to history")
            
            self.finished.emit(answer, "Ready")
            
        except Exception as e:
            error_msg = f"Unexpected error: {str(e)}"
            logging.error(f"LeaWorker error: {traceback.format_exc()}")
            self.error.emit(error_msg)
    
    def _handle_function_calls(self, function_calls: List[Dict], current_answer: str) -> str:
        """Handle function calls from OpenAI (replaces regex parsing)"""
        if not TASK_SYSTEM_AVAILABLE or not task_registry:
            return current_answer
        
        task_results = []
        
        for func_call in function_calls:
            try:
                func_name = func_call.get("name", "")
                func_args = func_call.get("arguments", "")
                
                # Parse function name to get task name
                if func_name.startswith("execute_task_"):
                    task_name = func_name.replace("execute_task_", "")
                else:
                    continue
                
                # Parse arguments
                try:
                    if isinstance(func_args, str):
                        params_dict = json.loads(func_args)
                    else:
                        params_dict = func_args
                    
                    # Extract task_name and params from the function arguments
                    actual_task_name = params_dict.get("task_name", task_name)
                    params = params_dict.get("params", {})
                except Exception as parse_error:
                    logging.warning(f"Error parsing function arguments: {parse_error}")
                    params = {}
                
                # Check if task requires confirmation
                task_obj = task_registry.get_task(actual_task_name)
                requires_confirmation = task_obj.requires_confirmation if task_obj else False
                
                # Execute task (auto-confirm for now, can be enhanced to ask user)
                result = task_registry.execute_task(actual_task_name, params, confirmed=not requires_confirmation)
                task_results.append({
                    "task": actual_task_name,
                    "params": params,
                    "result": result.to_dict()
                })
                
            except Exception as task_error:
                logging.warning(f"Task execution failed: {task_error}")
                task_results.append({
                    "task": func_call.get("name", "unknown"),
                    "params": {},
                    "result": {"success": False, "message": f"Error: {str(task_error)}"}
                })
        
        # Add task results to answer
        if task_results:
            results_text = "\n\n=== Task Execution Results ===\n"
            for tr in task_results:
                r = tr["result"]
                results_text += f"\n**Task: {tr['task']}**\n"
                results_text += f"Status: {'✅ Success' if r['success'] else '❌ Failed'}\n"
                results_text += f"Message: {r['message']}\n"
                if r.get('error'):
                    results_text += f"Error: {r['error']}\n"
            
            if all(tr["result"]["success"] for tr in task_results):
                return current_answer + results_text
            else:
                return current_answer + results_text + "\n\n⚠️ Some tasks failed. Please review and try again if needed."
        
        return current_answer

# =====================================================
# MAIN WINDOW
# =====================================================

class LeaWindow(QWidget):
    USER_COLOR = "#68BD47"
    ASSIST_COLOR = "#FFFFFF"
    SYSTEM_COLOR = "#2DBCEE"

    def __init__(self):
        super().__init__()
        
        self.current_mode = "General Assistant & Triage"
        self.current_model = "GPT-4o"  # Default model (GPT-4o (default) is an alias for backward compatibility)
        self.message_history = []
        self.history_file = "lea_history.json"
        self.current_file_content = None
        self.current_file_path = None
        
        # Configurable settings
        self.max_history_messages = 20  # Configurable history limit
        self.enable_response_cache = True  # Enable response caching
        self.cache_duration_hours = 24  # Cache responses for 24 hours
        self.response_cache = {}  # Cache dictionary
        
        # Initialize memory system
        self.memory_system = LeaMemory()
        if openai_client:
            self.memory_system.set_client(openai_client)
        
        # Streaming state
        self.current_streaming_response = ""
        self.is_streaming = False
        self.streaming_message_started = False
        self.streaming_cursor_position = None  # Track position of streaming message
        self.streaming_message_count = 0  # Count of Lea messages to track which one is streaming
        
        # TTS state
        self.tts_enabled = False
        self.tts_voice_lang = "en"
        self.tts_voice_tld = "com"  # Top-level domain for accent (com = US, co.uk = UK, etc.)
        
        # Speech Recognition state
        self.speech_recognizer = None
        if SPEECH_RECOGNITION_AVAILABLE:
            try:
                self.speech_recognizer = sr.Recognizer()
            except:
                pass
        self.microphone_device_index = None
        self.is_listening = False
        self.speech_worker_thread = None
        self.speech_worker = None
        
        # Status update methods
        self._update_tts_mic_status()
        
        # Thread references (prevent crashes from deleted threads)
        self.worker_thread = None
        self.worker = None
        self._current_worker = None
        self._current_thread = None
        
        self.file_worker_thread = None
        self.file_worker = None
        self._file_worker = None
        self._file_worker_thread = None
        
        self.download_worker_thread = None
        self.download_worker = None
        self._download_worker = None
        self._download_worker_thread = None
        
        self.export_worker_thread = None
        self.export_worker = None
        self._export_worker = None
        self._export_worker_thread = None
        
        # Settings
        self.settings_file = PROJECT_DIR / "lea_settings.json"
        self.load_settings()
        
        self._init_window()
        self._build_ui()
        self._load_history()
    
    def _init_window(self):
        self.setWindowTitle("Hummingbird – Lea Multi-Agent")
        if ICON_FILE.exists():
            self.setWindowIcon(QIcon(str(ICON_FILE)))
        self.resize(1200, 800)
        
        self.setStyleSheet("""
            QWidget { background-color: #333; color: #FFF; }
            QLabel { color: #FFF; }
            QComboBox { background-color: #222; color: #FFF; padding: 4px; }
            QFrame#InnerFrame { background-color: #333; border-radius: 8px; }
        """)
    
    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        
        frame = QFrame()
        frame.setObjectName("InnerFrame")
        frame_layout = QVBoxLayout(frame)
        
        # Header
        header = QHBoxLayout()
        title = QLabel("🐦 Lea Multi-Agent System")
        title.setStyleSheet("font-size: 20px; font-weight: 600;")
        header.addWidget(title)
        header.addStretch()
        
        header.addWidget(QLabel("Mode:"))
        self.mode_combo = QComboBox()
        self.mode_combo.addItems(list(AGENTS.keys()))
        self.mode_combo.currentTextChanged.connect(self.on_mode_changed)
        header.addWidget(self.mode_combo)
        
        header.addWidget(QLabel("Model:"))
        self.model_combo = QComboBox()
        self.model_combo.addItems(list(MODEL_OPTIONS.keys()))
        self.model_combo.currentTextChanged.connect(self.on_model_changed)
        header.addWidget(self.model_combo)
        
        if ICON_FILE.exists():
            icon = QLabel()
            icon.setPixmap(QPixmap(str(ICON_FILE)).scaled(32, 32, Qt.AspectRatioMode.KeepAspectRatio))
            header.addWidget(icon)
        
        frame_layout.addLayout(header)
        
        # Buttons
        buttons = QHBoxLayout()
        
        upload_btn = QPushButton("📎 Upload")
        upload_btn.clicked.connect(self.upload_file)
        upload_btn.setStyleSheet("background-color: #0078D7; padding: 6px 12px; border-radius: 4px;")
        buttons.addWidget(upload_btn)
        
        download_btn = QPushButton("📥 Download")
        download_btn.clicked.connect(self.download_response)
        download_btn.setStyleSheet("background-color: #107C10; padding: 6px 12px; border-radius: 4px;")
        buttons.addWidget(download_btn)
        
        export_btn = QPushButton("Export")
        export_btn.clicked.connect(self.export_conversation)
        export_btn.setStyleSheet("background-color: #0078D7; padding: 6px 12px; border-radius: 4px;")
        buttons.addWidget(export_btn)
        
        # TTS toggle button
        if TTS_AVAILABLE:
            self.tts_btn = QPushButton("🔇 TTS Off")
            self.tts_btn.clicked.connect(self.toggle_tts)
            self.tts_btn.setStyleSheet("background-color: #6B46C1; padding: 6px 12px; border-radius: 4px;")
            self.tts_btn.setCheckable(True)
            buttons.addWidget(self.tts_btn)
        
        if TASK_SYSTEM_AVAILABLE:
            tasks_btn = QPushButton("🤖 Tasks")
            tasks_btn.clicked.connect(self.show_tasks_dialog)
            tasks_btn.setStyleSheet("background-color: #6B46C1; padding: 6px 12px; border-radius: 4px;")
            buttons.addWidget(tasks_btn)
            
            # Coordinate finder button
            coord_btn = QPushButton("📍 Coords")
            coord_btn.clicked.connect(self.show_coordinate_finder)
            coord_btn.setStyleSheet("background-color: #6B46C1; padding: 6px 12px; border-radius: 4px;")
            coord_btn.setToolTip("Click to show mouse coordinates")
            buttons.addWidget(coord_btn)
        
        clear_btn = QPushButton("Clear")
        clear_btn.clicked.connect(self.clear_conversation)
        clear_btn.setStyleSheet("background-color: #D13438; padding: 6px 12px; border-radius: 4px;")
        buttons.addWidget(clear_btn)
        
        buttons.addStretch()
        frame_layout.addLayout(buttons)
        
        # File status
        self.file_label = QLabel("")
        self.file_label.setStyleSheet("color: #68BD47; font-size: 11px; font-style: italic;")
        frame_layout.addWidget(self.file_label)
        
        # Chat display
        self.chat_display = QTextEdit()
        self.chat_display.setReadOnly(True)
        self.chat_display.setStyleSheet(
            "background-color: #222; color: #FFF; font-size: 16px; "
            "font-family: Consolas, monospace;"
        )
        frame_layout.addWidget(self.chat_display, stretch=1)
        
        # Input
        input_layout = QHBoxLayout()
        
        # Emoji button
        emoji_btn = QPushButton("😊")
        emoji_btn.setToolTip("Insert emoji")
        emoji_btn.setMinimumWidth(45)
        emoji_btn.setMaximumWidth(45)
        emoji_btn.setStyleSheet("background-color: #444; font-size: 20px; border-radius: 4px; padding: 4px;")
        emoji_btn.clicked.connect(self.show_emoji_picker)
        input_layout.addWidget(emoji_btn)
        
        # Microphone button (if speech recognition available)
        if SPEECH_RECOGNITION_AVAILABLE:
            self.mic_btn = QPushButton("🎤")
            self.mic_btn.setToolTip("Click to speak your question")
            self.mic_btn.setMinimumWidth(45)
            self.mic_btn.setMaximumWidth(45)
            self.mic_btn.setStyleSheet("background-color: #444; font-size: 20px; border-radius: 4px; padding: 4px;")
            self.mic_btn.clicked.connect(self.toggle_speech_recognition)
            input_layout.addWidget(self.mic_btn)
        
        self.input_box = ChatInputBox()
        self.input_box.setPlaceholderText("Ask Lea anything... (Enter to send, Shift+Enter for new line)\n💡 Tip: Drag & drop files here or paste text snippets")
        self.input_box.returnPressed.connect(self.on_send)
        self.input_box.fileDropped.connect(self.on_file_dropped)  # Handle dropped files
        self.input_box.setMinimumHeight(80)
        self.input_box.setStyleSheet("background-color: #222; color: #FFF; font-size: 16px;")
        input_layout.addWidget(self.input_box, stretch=1)
        
        send_btn = QPushButton("Send")
        send_btn.clicked.connect(self.on_send)
        send_btn.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Expanding)
        send_btn.setMinimumWidth(90)
        send_btn.setStyleSheet("background-color: #0078D7; font-size: 16px; font-weight: 600; border-radius: 4px;")
        input_layout.addWidget(send_btn)
        
        frame_layout.addLayout(input_layout)
        
        # Options
        options = QHBoxLayout()
        self.include_file_cb = QCheckBox("Include uploaded file in context")
        self.include_file_cb.setChecked(True)
        options.addWidget(self.include_file_cb)
        options.addStretch()
        frame_layout.addLayout(options)
        
        # Status indicators (two separate indicators)
        status_layout = QHBoxLayout()
        status_layout.setSpacing(10)
        
        # TTS/Microphone status indicator
        self.tts_mic_status = QLabel("🔴 TTS/Mic: Inactive")
        self.tts_mic_status.setStyleSheet("""
            QLabel {
                color: #FF4444;
                font-size: 12px;
                font-weight: 600;
                padding: 4px 8px;
                background-color: #2a2a2a;
                border-radius: 4px;
            }
        """)
        status_layout.addWidget(self.tts_mic_status)
        
        # Conversation status indicator
        self.conversation_status = QLabel("Ready")
        self.conversation_status.setStyleSheet("""
            QLabel {
                color: #68BD47;
                font-size: 12px;
                font-weight: 600;
                padding: 4px 8px;
                background-color: #2a2a2a;
                border-radius: 4px;
            }
        """)
        status_layout.addWidget(self.conversation_status)
        
        status_layout.addStretch()
        frame_layout.addLayout(status_layout)
        
        # Keep status_label for backward compatibility (will update conversation_status)
        self.status_label = self.conversation_status
        
        # Initialize status indicators
        self._update_tts_mic_status()
        self._update_conversation_status("Ready", "ready")
        
        layout.addWidget(frame)
    
    # File operations
    def on_file_dropped(self, file_path: str):
        """Handle file dropped into input box"""
        if not file_path:
            return
        
        # Check if file exists
        path_obj = Path(file_path)
        if not path_obj.exists():
            QMessageBox.warning(self, "File Not Found", f"File not found:\n{file_path}")
            return
        
        # Check if it's a file (not a directory)
        if not path_obj.is_file():
            QMessageBox.information(self, "Directory Dropped", "Please drop a file, not a directory.")
            return
        
        # Upload the dropped file
        self._upload_file_path(file_path)
    
    def upload_file(self):
        if not FILE_READER_AVAILABLE:
            QMessageBox.warning(self, "Error", "universal_file_reader.py not found")
            return
        path, _ = QFileDialog.getOpenFileName(self, "Upload File", "", "All Files (*)")
        if not path:
            return
        self._upload_file_path(path)
    
    def _upload_file_path(self, path: str):
        """Internal method to upload a file by path"""
        if not FILE_READER_AVAILABLE:
            QMessageBox.warning(self, "Error", "universal_file_reader.py not found")
            return
        
        self._update_conversation_status("Reading file...", "processing")
        QApplication.processEvents()
        # Clean up any existing file worker thread
        try:
            if hasattr(self, 'file_worker_thread') and self.file_worker_thread is not None:
                try:
                    if hasattr(self, 'file_worker') and self.file_worker is not None:
                        try:
                            self.file_worker.finished.disconnect()
                            self.file_worker.error.disconnect()
                        except:
                            pass
                except:
                    pass
        except:
            pass
        
        # Start file upload worker thread
        self.file_worker_thread = QThread()
        self.file_worker = FileUploadWorker(path)
        self.file_worker.moveToThread(self.file_worker_thread)
        
        # Store references
        self._file_worker = self.file_worker
        self._file_worker_thread = self.file_worker_thread
        
        self.file_worker_thread.started.connect(self.file_worker.run)
        self.file_worker.finished.connect(self.on_file_upload_finished)
        self.file_worker.error.connect(self.on_file_upload_error)
        self.file_worker.finished.connect(self.file_worker_thread.quit)
        self.file_worker.error.connect(self.file_worker_thread.quit)
        
        def safe_delete_file_worker():
            try:
                if hasattr(self, '_file_worker') and self._file_worker:
                    self._file_worker.deleteLater()
                    self._file_worker = None
            except:
                pass
        
        def safe_delete_file_thread():
            try:
                if hasattr(self, '_file_worker_thread') and self._file_worker_thread:
                    self._file_worker_thread.deleteLater()
                    self._file_worker_thread = None
                    if hasattr(self, 'file_worker_thread'):
                        self.file_worker_thread = None
            except:
                pass
        
        self.file_worker_thread.finished.connect(safe_delete_file_worker)
        self.file_worker_thread.finished.connect(safe_delete_file_thread)
        self.file_worker_thread.start()

    def on_file_upload_finished(self, result, backup_path, file_name):
        try:
            # Store file path before worker is deleted (use stored reference)
            if result['success']:
                # Get path from stored reference or result
                if hasattr(self, '_file_worker') and self._file_worker and hasattr(self._file_worker, 'path'):
                    self.current_file_path = self._file_worker.path
                elif hasattr(self, 'file_worker') and self.file_worker and hasattr(self.file_worker, 'path'):
                    try:
                        self.current_file_path = self.file_worker.path
                    except (RuntimeError, AttributeError):
                        # Worker deleted, use backup_path if available
                        if backup_path:
                            self.current_file_path = backup_path
                
                self.current_file_content = result.get('content', '')
                self.file_label.setText(f"📎 {file_name} ({result.get('file_type', 'unknown')})")
                self.append_message("system", f"Uploaded: {file_name}\nBackup: {os.path.basename(backup_path) if backup_path else 'None'}")
                self._update_conversation_status("File loaded", "ready")
            else:
                QMessageBox.warning(self, "Error", result.get('error', 'Unknown error'))
                self._update_conversation_status("Error loading file", "error")
            
            # Clean up reference
            try:
                if hasattr(self, '_file_worker'):
                    self._file_worker = None
            except:
                pass
        except Exception as e:
            logging.error(f"Error in on_file_upload_finished: {traceback.format_exc()}")
            try:
                self._update_conversation_status("Error loading file", "error")
            except:
                pass

    def on_file_upload_error(self, error_msg):
        try:
            error_text = str(error_msg) if error_msg else "Unknown error"
            QMessageBox.warning(self, "File Upload Error", error_text)
            self._update_conversation_status("Error loading file", "error")
        except Exception as e:
            logging.error(f"Error in on_file_upload_error: {traceback.format_exc()}")
            self._update_conversation_status("Error", "error")
    
    def download_response(self):
        if not self.message_history:
            QMessageBox.information(self, "Nothing to Download", "No conversation to save")
            return
        # Get last assistant response
        last_response = None
        for msg in reversed(self.message_history):
            if msg['role'] == 'assistant':
                last_response = msg['content']
                break
        if not last_response:
            QMessageBox.information(self, "Nothing to Download", "No response to save")
            return
        # Clean up any existing download worker thread
        try:
            if hasattr(self, 'download_worker_thread') and self.download_worker_thread is not None:
                try:
                    if hasattr(self, 'download_worker') and self.download_worker is not None:
                        try:
                            self.download_worker.finished.disconnect()
                            self.download_worker.error.disconnect()
                        except:
                            pass
                except:
                    pass
        except:
            pass
        
        # Start download worker thread
        self.download_worker_thread = QThread()
        self.download_worker = DownloadWorker(last_response)
        self.download_worker.moveToThread(self.download_worker_thread)
        
        # Store references
        self._download_worker = self.download_worker
        self._download_worker_thread = self.download_worker_thread
        
        self.download_worker_thread.started.connect(self.download_worker.run)
        self.download_worker.finished.connect(self.on_download_finished)
        self.download_worker.error.connect(self.on_download_error)
        self.download_worker.finished.connect(self.download_worker_thread.quit)
        self.download_worker.error.connect(self.download_worker_thread.quit)
        
        def safe_delete_download_worker():
            try:
                if hasattr(self, '_download_worker') and self._download_worker:
                    self._download_worker.deleteLater()
                    self._download_worker = None
            except:
                pass
        
        def safe_delete_download_thread():
            try:
                if hasattr(self, '_download_worker_thread') and self._download_worker_thread:
                    self._download_worker_thread.deleteLater()
                    self._download_worker_thread = None
                    if hasattr(self, 'download_worker_thread'):
                        self.download_worker_thread = None
            except:
                pass
        
        self.download_worker_thread.finished.connect(safe_delete_download_worker)
        self.download_worker_thread.finished.connect(safe_delete_download_thread)
        self.download_worker_thread.start()

    def on_download_finished(self, download_path, basename):
        try:
            self.append_message("system", f"Downloaded to: {basename}")
            QMessageBox.information(self, "Downloaded", f"Saved to:\n{download_path}")
            
            # Clean up reference
            try:
                if hasattr(self, '_download_worker'):
                    self._download_worker = None
            except:
                pass
        except Exception as e:
            logging.error(f"Error in on_download_finished: {traceback.format_exc()}")

    def on_download_error(self, error_msg):
        try:
            error_text = str(error_msg) if error_msg else "Unknown error"
            QMessageBox.warning(self, "Download Error", error_text)
            
            # Clean up reference
            try:
                if hasattr(self, '_download_worker'):
                    self._download_worker = None
            except:
                pass
        except Exception as e:
            logging.error(f"Error in on_download_error: {traceback.format_exc()}")
    
    def export_conversation(self):
        path, _ = QFileDialog.getSaveFileName(self, "Export", "", "JSON (*.json);;Text (*.txt)")
        if not path:
            return
        # Clean up any existing export worker thread
        try:
            if hasattr(self, 'export_worker_thread') and self.export_worker_thread is not None:
                try:
                    if hasattr(self, 'export_worker') and self.export_worker is not None:
                        try:
                            self.export_worker.finished.disconnect()
                            self.export_worker.error.disconnect()
                        except:
                            pass
                except:
                    pass
        except:
            pass
        
        # Start export worker thread
        self.export_worker_thread = QThread()
        self.export_worker = ExportWorker(
            path,
            self.current_mode,
            self.current_model,
            self.message_history,
            self.chat_display.toPlainText()
        )
        self.export_worker.moveToThread(self.export_worker_thread)
        
        # Store references
        self._export_worker = self.export_worker
        self._export_worker_thread = self.export_worker_thread
        
        self.export_worker_thread.started.connect(self.export_worker.run)
        self.export_worker.finished.connect(self.on_export_finished)
        self.export_worker.error.connect(self.on_export_error)
        self.export_worker.finished.connect(self.export_worker_thread.quit)
        self.export_worker.error.connect(self.export_worker_thread.quit)
        
        def safe_delete_export_worker():
            try:
                if hasattr(self, '_export_worker') and self._export_worker:
                    self._export_worker.deleteLater()
                    self._export_worker = None
            except:
                pass
        
        def safe_delete_export_thread():
            try:
                if hasattr(self, '_export_worker_thread') and self._export_worker_thread:
                    self._export_worker_thread.deleteLater()
                    self._export_worker_thread = None
                    if hasattr(self, 'export_worker_thread'):
                        self.export_worker_thread = None
            except:
                pass
        
        self.export_worker_thread.finished.connect(safe_delete_export_worker)
        self.export_worker_thread.finished.connect(safe_delete_export_thread)
        self.export_worker_thread.start()

    def on_export_finished(self, path):
        try:
            QMessageBox.information(self, "Exported", f"Saved to:\n{path}")
            
            # Clean up reference
            try:
                if hasattr(self, '_export_worker'):
                    self._export_worker = None
            except:
                pass
        except Exception as e:
            logging.error(f"Error in on_export_finished: {traceback.format_exc()}")

    def on_export_error(self, error_msg):
        try:
            error_text = str(error_msg) if error_msg else "Unknown error"
            QMessageBox.warning(self, "Export Error", error_text)
            
            # Clean up reference
            try:
                if hasattr(self, '_export_worker'):
                    self._export_worker = None
            except:
                pass
        except Exception as e:
            logging.error(f"Error in on_export_error: {traceback.format_exc()}")
    
    def show_tasks_dialog(self):
        """Show task management dialog"""
        if not TASK_SYSTEM_AVAILABLE:
            QMessageBox.warning(self, "Tasks Unavailable", "Task system is not available.")
            return
        
        dialog = QDialog(self)
        dialog.setWindowTitle("🤖 Lea Task Management")
        dialog.setMinimumSize(800, 600)
        
        layout = QVBoxLayout(dialog)
        
        # Title
        title = QLabel("Available Tasks")
        title.setStyleSheet("font-size: 18px; font-weight: 600;")
        layout.addWidget(title)
        
        # Task list table
        table = QTableWidget()
        table.setColumnCount(4)
        table.setHorizontalHeaderLabels(["Task Name", "Description", "Confirmation Required", "Status"])
        table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        
        tasks = task_registry.list_tasks()
        table.setRowCount(len(tasks))
        
        for row, task in enumerate(tasks):
            table.setItem(row, 0, QTableWidgetItem(task["name"]))
            table.setItem(row, 1, QTableWidgetItem(task["description"]))
            table.setItem(row, 2, QTableWidgetItem("Yes" if task["requires_confirmation"] else "No"))
            status = "✅ Enabled" if task["allowed"] else "❌ Disabled"
            table.setItem(row, 3, QTableWidgetItem(status))
        
        layout.addWidget(table)
        
        # Buttons
        buttons = QHBoxLayout()
        
        enable_btn = QPushButton("Enable Selected")
        enable_btn.clicked.connect(lambda: self.toggle_task_status(table, True))
        buttons.addWidget(enable_btn)
        
        disable_btn = QPushButton("Disable Selected")
        disable_btn.clicked.connect(lambda: self.toggle_task_status(table, False))
        buttons.addWidget(disable_btn)
        
        buttons.addStretch()
        
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(dialog.accept)
        buttons.addWidget(close_btn)
        
        layout.addLayout(buttons)
        
        # Show task history
        history_group = QGroupBox("Recent Task History")
        history_layout = QVBoxLayout()
        history_text = QTextEdit()
        history_text.setReadOnly(True)
        history_text.setMaximumHeight(150)
        
        history = task_registry.task_history[-10:]  # Last 10 tasks
        if history:
            history_content = "\n".join([
                f"{item['timestamp']}: {item['task_name']} - {'✅' if item['result']['success'] else '❌'} {item['result']['message']}"
                for item in reversed(history)
            ])
            history_text.setText(history_content)
        else:
            history_text.setText("No task history yet.")
        
        history_layout.addWidget(history_text)
        history_group.setLayout(history_layout)
        layout.addWidget(history_group)
        
        dialog.exec()
    
    def toggle_task_status(self, table, enable):
        """Enable or disable selected task"""
        selected = table.selectedItems()
        if not selected:
            QMessageBox.information(self, "No Selection", "Please select a task from the table.")
            return
        
        row = selected[0].row()
        task_name = table.item(row, 0).text()
        
        if enable:
            task_registry.enable_task(task_name)
        else:
            reply = QMessageBox.question(
                self, "Disable Task",
                f"Are you sure you want to disable '{task_name}'?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if reply == QMessageBox.StandardButton.Yes:
                task_registry.disable_task(task_name)
        
        # Refresh table
        status = "✅ Enabled" if enable else "❌ Disabled"
        table.setItem(row, 3, QTableWidgetItem(status))
    
    def show_emoji_picker(self):
        """Show emoji picker dialog with search functionality"""
        # Helper function to generate emoji names from Unicode CLDR data patterns
        def generate_emoji_name(emoji, category):
            """Generate a reasonable name for an emoji based on common patterns"""
            # Common emoji name patterns - this is a simplified version
            # In a full implementation, you'd use Unicode CLDR data
            name_map = {
                # Faces
                "😊": "smiling face", "😀": "grinning face", "😃": "grinning face big eyes", 
                "😄": "grinning face smiling eyes", "😁": "beaming face", "😆": "grinning squinting face",
                "😅": "grinning face sweat", "🤣": "rolling on floor laughing", "😂": "face with tears of joy",
                "🙂": "slightly smiling face", "🙃": "upside down face", "😉": "winking face",
                "😌": "relieved face", "😍": "smiling face heart eyes", "🥰": "smiling face hearts",
                "😘": "face blowing kiss", "😗": "kissing face", "😙": "kissing face smiling eyes",
                "😚": "kissing face closed eyes", "😋": "face savoring food", "😛": "face with tongue",
                "😝": "squinting face tongue", "😜": "winking face tongue", "🤪": "zany face",
                "🤨": "raised eyebrow", "🧐": "face with monocle", "🤓": "nerd face", "😎": "smiling face sunglasses",
                "🤩": "star struck", "🥳": "partying face", "😏": "smirking face", "😒": "unamused face",
                "😞": "disappointed face", "😔": "pensive face", "😟": "worried face", "😕": "slightly frowning face",
                "🙁": "slightly frowning face", "☹️": "frowning face", "😣": "persevering face", "😖": "confounded face",
                "😫": "tired face", "😩": "weary face", "🥺": "pleading face", "😢": "crying face",
                "😭": "loudly crying face", "😤": "face with steam", "😠": "angry face", "😡": "pouting face",
                "🤬": "face with symbols", "🤯": "exploding head", "😳": "flushed face", "🥵": "hot face",
                "🥶": "cold face", "😱": "face screaming fear", "😨": "fearful face", "😰": "anxious face sweat",
                "😥": "sad relieved face", "😓": "downcast face sweat", "🤢": "nauseated face", "🤮": "face vomiting",
                "🤧": "sneezing face", "🥴": "woozy face", "😴": "sleeping face", "🤤": "drooling face",
                "😪": "sleepy face", "😵": "dizzy face", "🤐": "zipper mouth face", "🥱": "yawning face",
                "😷": "face with medical mask",
                # Hand Gestures
                "👋": "waving hand", "🤚": "raised back of hand", "🖐️": "hand with fingers splayed", "✋": "raised hand",
                "🖖": "vulcan salute", "👌": "ok hand", "🤌": "pinched fingers", "🤏": "pinching hand",
                "✌️": "victory hand", "🤞": "crossed fingers", "🤟": "love you gesture", "🤘": "sign of the horns",
                "🤙": "call me hand", "👈": "backhand index pointing left", "👉": "backhand index pointing right",
                "👆": "backhand index pointing up", "🖕": "middle finger", "👇": "backhand index pointing down",
                "☝️": "index pointing up", "👍": "thumbs up", "👎": "thumbs down", "✊": "raised fist",
                "👊": "oncoming fist", "🤛": "left facing fist", "🤜": "right facing fist", "👏": "clapping hands",
                "🙌": "raising hands", "👐": "open hands", "🤲": "palms up together", "🤝": "handshake",
                "🙏": "folded hands", "✍️": "writing hand", "💪": "flexed biceps", "🦾": "mechanical arm", "🦿": "mechanical leg",
                # Animals
                "🐶": "dog face", "🐱": "cat face", "🐭": "mouse face", "🐹": "hamster", "🐰": "rabbit face",
                "🦊": "fox", "🐻": "bear", "🐼": "panda", "🐨": "koala", "🐯": "tiger face", "🦁": "lion",
                "🐮": "cow face", "🐷": "pig face", "🐽": "pig nose", "🐸": "frog", "🐵": "monkey face",
                "🙈": "see no evil monkey", "🙉": "hear no evil monkey", "🙊": "speak no evil monkey", "🐒": "monkey",
                "🐔": "chicken", "🐧": "penguin", "🐦": "bird", "🐤": "baby chick", "🐣": "hatching chick",
                "🐥": "front facing baby chick", "🦆": "duck", "🦅": "eagle", "🦉": "owl", "🦇": "bat",
                "🐺": "wolf", "🐗": "boar", "🐴": "horse face", "🦄": "unicorn", "🐝": "honeybee",
                "🐛": "bug", "🦋": "butterfly", "🐌": "snail", "🐞": "lady beetle", "🐜": "ant",
                "🦟": "mosquito", "🦗": "cricket", "🕷️": "spider", "🦂": "scorpion", "🐢": "turtle",
                "🐍": "snake", "🦎": "lizard", "🦖": "t rex", "🦕": "sauropod", "🐙": "octopus",
                "🦑": "squid", "🦐": "shrimp", "🦞": "lobster", "🦀": "crab", "🐡": "blowfish",
                "🐠": "tropical fish", "🐟": "fish", "🐬": "dolphin", "🐳": "spouting whale", "🐋": "whale",
                "🦈": "shark", "🐊": "crocodile", "🐅": "tiger", "🐆": "leopard", "🦓": "zebra",
                "🦍": "gorilla", "🦧": "orangutan", "🐘": "elephant", "🦛": "hippopotamus", "🦏": "rhinoceros",
                "🐪": "camel", "🐫": "two hump camel", "🦒": "giraffe", "🦘": "kangaroo", "🦬": "bison",
                "🐃": "water buffalo", "🐂": "ox", "🐄": "cow", "🐎": "horse", "🐖": "pig",
                "🐏": "ram", "🐑": "ewe", "🦙": "llama", "🐐": "goat", "🦌": "deer",
                "🐕": "dog", "🐩": "poodle", "🦮": "guide dog", "🐕‍🦺": "service dog", "🐈": "cat",
                "🐓": "rooster", "🦃": "turkey", "🦤": "dodo", "🦚": "peacock", "🦜": "parrot",
                "🦢": "swan", "🦩": "flamingo", "🕊️": "dove", "🐇": "rabbit", "🦝": "raccoon",
                "🦨": "skunk", "🦡": "badger", "🦫": "beaver", "🦦": "otter", "🦥": "sloth",
                "🐁": "mouse", "🐀": "rat", "🐿️": "chipmunk",
                # Food
                "🍏": "green apple", "🍎": "red apple", "🍐": "pear", "🍊": "tangerine", "🍋": "lemon",
                "🍌": "banana", "🍉": "watermelon", "🍇": "grapes", "🍓": "strawberry", "🍈": "melon",
                "🍒": "cherries", "🍑": "peach", "🥭": "mango", "🍍": "pineapple", "🥥": "coconut",
                "🥝": "kiwi fruit", "🍅": "tomato", "🍆": "eggplant", "🥑": "avocado", "🥦": "broccoli",
                "🥬": "leafy green", "🥒": "cucumber", "🌶️": "hot pepper", "🌽": "corn", "🥕": "carrot",
                "🥔": "potato", "🍠": "roasted sweet potato", "🥐": "croissant", "🥯": "bagel", "🍞": "bread",
                "🥖": "baguette bread", "🥨": "pretzel", "🧀": "cheese", "🥚": "egg", "🍳": "cooking",
                "🥞": "pancakes", "🥓": "bacon", "🥩": "cut of meat", "🍗": "poultry leg", "🍖": "meat on bone",
                "🦴": "bone", "🌭": "hot dog", "🍔": "hamburger", "🍟": "french fries", "🍕": "pizza",
                "🥪": "sandwich", "🥙": "stuffed flatbread", "🌮": "taco", "🌯": "burrito", "🥗": "green salad",
                "🥘": "shallow pan of food", "🥫": "canned food", "🍝": "spaghetti", "🍜": "steaming bowl",
                "🍲": "pot of food", "🍛": "curry rice", "🍣": "sushi", "🍱": "bento box", "🥟": "dumpling",
                "🦪": "oyster", "🍤": "fried shrimp", "🍙": "rice ball", "🍚": "cooked rice", "🍘": "rice cracker",
                "🍥": "fish cake", "🥠": "fortune cookie", "🥮": "moon cake", "🍢": "oden", "🍡": "dango",
                "🍧": "shaved ice", "🍨": "ice cream", "🍦": "soft ice cream", "🥧": "pie", "🧁": "cupcake",
                "🍰": "birthday cake", "🎂": "birthday cake", "🍮": "custard", "🍭": "lollipop", "🍬": "candy",
                "🍫": "chocolate bar", "🍿": "popcorn", "🍩": "doughnut", "🍪": "cookie", "🌰": "chestnut",
                "🥜": "peanuts", "🍯": "honey pot", "🥛": "glass of milk", "🍼": "baby bottle", "☕️": "hot beverage",
                "🍵": "teacup", "🧃": "beverage box", "🥤": "cup with straw", "🍶": "sake", "🍺": "beer mug",
                "🍻": "clinking beer mugs", "🥂": "clinking glasses", "🍷": "wine glass", "🥃": "tumbler glass",
                "🍸": "cocktail glass", "🍹": "tropical drink", "🧉": "mate", "🍾": "bottle with popping cork",
                # Common symbols
                "❤️": "red heart", "🧡": "orange heart", "💛": "yellow heart", "💚": "green heart",
                "💙": "blue heart", "💜": "purple heart", "🖤": "black heart", "🤍": "white heart",
                "🤎": "brown heart", "💔": "broken heart", "❣️": "heart exclamation", "💕": "two hearts",
                "💞": "revolving hearts", "💓": "beating heart", "💗": "growing heart", "💖": "sparkling heart",
                "💘": "heart with arrow", "💝": "heart with ribbon", "💟": "heart decoration",
                "✅": "check mark button", "☑️": "check box with check", "✔️": "check mark",
                "❌": "cross mark", "❎": "cross mark button", "➕": "plus", "➖": "minus",
                "➗": "division", "❓": "question mark", "❔": "white question mark", "❕": "white exclamation mark",
                "❗": "exclamation mark", "💯": "hundred points", "🔴": "red circle", "🟠": "orange circle",
                "🟡": "yellow circle", "🟢": "green circle", "🔵": "blue circle", "🟣": "purple circle",
                "⚫": "black circle", "⚪": "white circle", "🟤": "brown circle",
            }
            
            if emoji in name_map:
                return name_map[emoji]
            
            # Fallback: try to infer from category
            category_lower = category.lower()
            if "face" in category_lower or "emotion" in category_lower:
                return f"face emoji {emoji}"
            elif "hand" in category_lower or "gesture" in category_lower:
                return f"hand gesture {emoji}"
            elif "animal" in category_lower or "nature" in category_lower:
                return f"animal {emoji}"
            elif "food" in category_lower or "drink" in category_lower:
                return f"food {emoji}"
            elif "travel" in category_lower or "place" in category_lower:
                return f"place {emoji}"
            elif "sport" in category_lower or "activity" in category_lower:
                return f"sport {emoji}"
            elif "object" in category_lower or "tech" in category_lower:
                return f"object {emoji}"
            elif "symbol" in category_lower or "sign" in category_lower:
                return f"symbol {emoji}"
            elif "flag" in category_lower:
                return f"flag {emoji}"
            elif "weather" in category_lower:
                return f"weather {emoji}"
            else:
                return f"emoji {emoji}"
        
        emoji_names = {}  # Will be populated by generate_emoji_name
        
        # Comprehensive emoji library organized by category with search keywords
        emojis_data = {
            "Faces & Emotions": {
                "emojis": ["😊", "😀", "😃", "😄", "😁", "😆", "😅", "🤣", "😂", "🙂", "🙃", "😉", "😌", "😍", "🥰", "😘", "😗", "😙", "😚", "😋", "😛", "😝", "😜", "🤪", "🤨", "🧐", "🤓", "😎", "🤩", "🥳", "😏", "😒", "😞", "😔", "😟", "😕", "🙁", "☹️", "😣", "😖", "😫", "😩", "🥺", "😢", "😭", "😤", "😠", "😡", "🤬", "🤯", "😳", "🥵", "🥶", "😱", "😨", "😰", "😥", "😓", "🤢", "🤮", "🤧", "🥴", "😴", "🤤", "😪", "😵", "🤐", "🥱", "😷"],
                "keywords": "smile happy laugh grin face emotion feeling sad angry cry"
            },
            "Hand Gestures": {
                "emojis": ["👋", "🤚", "🖐️", "✋", "🖖", "👌", "🤌", "🤏", "✌️", "🤞", "🤟", "🤘", "🤙", "👈", "👉", "👆", "🖕", "👇", "☝️", "👍", "👎", "✊", "👊", "🤛", "🤜", "👏", "🙌", "👐", "🤲", "🤝", "🙏", "✍️", "💪", "🦾", "🦿"],
                "keywords": "hand wave thumbs up clap point gesture fingers"
            },
            "People & Body": {
                "emojis": ["👤", "👥", "🧑", "👨", "👩", "🧑‍🦱", "👨‍🦱", "👩‍🦱", "🧑‍🦰", "👨‍🦰", "👩‍🦰", "👱", "👱‍♂️", "👱‍♀️", "🧑‍🦳", "👨‍🦳", "👩‍🦳", "🧑‍🦲", "👨‍🦲", "👩‍🦲", "🧔", "👵", "🧓", "👴", "👲", "👳", "👳‍♂️", "👳‍♀️", "🧕", "👮", "👮‍♂️", "👮‍♀️", "👷", "👷‍♂️", "👷‍♀️", "💂", "💂‍♂️", "💂‍♀️", "🕵️", "🕵️‍♂️", "🕵️‍♀️", "👩‍⚕️", "👨‍⚕️", "👩‍🌾", "👨‍🌾", "👩‍🍳", "👨‍🍳", "👩‍🎓", "👨‍🎓", "👩‍🎤", "👨‍🎤", "👩‍🏫", "👨‍🏫", "👩‍🏭", "👨‍🏭", "👩‍💻", "👨‍💻", "👩‍💼", "👨‍💼", "👩‍🔧", "👨‍🔧", "👩‍🔬", "👨‍🔬", "👩‍🎨", "👨‍🎨", "👩‍🚒", "👨‍🚒", "👩‍✈️", "👨‍✈️", "👩‍🚀", "👨‍🚀", "👩‍⚖️", "👨‍⚖️", "🤶", "🎅", "🧙‍♀️", "🧙‍♂️", "🧝‍♀️", "🧝‍♂️", "🧛‍♀️", "🧛‍♂️", "🧟‍♀️", "🧟‍♂️", "🧞‍♀️", "🧞‍♂️", "🧜‍♀️", "🧜‍♂️", "🧚‍♀️", "🧚‍♂️", "👼", "🤰", "🤱", "👶", "🧒", "👦", "👧", "🧑", "👨", "👩", "👨‍👩‍👧", "👨‍👩‍👧‍👦", "👨‍👩‍👦‍👦", "👨‍👩‍👧‍👧", "👨‍👨‍👦", "👨‍👨‍👧", "👨‍👨‍👧‍👦", "👨‍👨‍👦‍👦", "👨‍👨‍👧‍👧", "👩‍👩‍👦", "👩‍👩‍👧", "👩‍👩‍👧‍👦", "👩‍👩‍👦‍👦", "👩‍👩‍👧‍👧"],
                "keywords": "person people body man woman child family"
            },
            "Animals & Nature": {
                "emojis": ["🐶", "🐱", "🐭", "🐹", "🐰", "🦊", "🐻", "🐼", "🐨", "🐯", "🦁", "🐮", "🐷", "🐽", "🐸", "🐵", "🙈", "🙉", "🙊", "🐒", "🐔", "🐧", "🐦", "🐤", "🐣", "🐥", "🦆", "🦅", "🦉", "🦇", "🐺", "🐗", "🐴", "🦄", "🐝", "🐛", "🦋", "🐌", "🐞", "🐜", "🦟", "🦗", "🕷️", "🦂", "🐢", "🐍", "🦎", "🦖", "🦕", "🐙", "🦑", "🦐", "🦞", "🦀", "🐡", "🐠", "🐟", "🐬", "🐳", "🐋", "🦈", "🐊", "🐅", "🐆", "🦓", "🦍", "🦧", "🐘", "🦛", "🦏", "🐪", "🐫", "🦒", "🦘", "🦬", "🐃", "🐂", "🐄", "🐎", "🐖", "🐏", "🐑", "🦙", "🐐", "🦌", "🐕", "🐩", "🦮", "🐕‍🦺", "🐈", "🐓", "🦃", "🦤", "🦚", "🦜", "🦢", "🦩", "🕊️", "🐇", "🦝", "🦨", "🦡", "🦫", "🦦", "🦥", "🐁", "🐀", "🐿️"],
                "keywords": "animal dog cat bird nature pet wildlife"
            },
            "Food & Drink": {
                "emojis": ["🍏", "🍎", "🍐", "🍊", "🍋", "🍌", "🍉", "🍇", "🍓", "🍈", "🍒", "🍑", "🥭", "🍍", "🥥", "🥝", "🍅", "🍆", "🥑", "🥦", "🥬", "🥒", "🌶️", "🌽", "🥕", "🥔", "🍠", "🥐", "🥯", "🍞", "🥖", "🥨", "🧀", "🥚", "🍳", "🥞", "🥓", "🥩", "🍗", "🍖", "🦴", "🌭", "🍔", "🍟", "🍕", "🥪", "🥙", "🌮", "🌯", "🥗", "🥘", "🥫", "🍝", "🍜", "🍲", "🍛", "🍣", "🍱", "🥟", "🦪", "🍤", "🍙", "🍚", "🍘", "🍥", "🥠", "🥮", "🍢", "🍡", "🍧", "🍨", "🍦", "🥧", "🧁", "🍰", "🎂", "🍮", "🍭", "🍬", "🍫", "🍿", "🍩", "🍪", "🌰", "🥜", "🍯", "🥛", "🍼", "☕️", "🍵", "🧃", "🥤", "🍶", "🍺", "🍻", "🥂", "🍷", "🥃", "🍸", "🍹", "🧉", "🍾"],
                "keywords": "food drink eat meal snack fruit vegetable pizza burger"
            },
            "Travel & Places": {
                "emojis": ["🏔️", "⛰️", "🌋", "🗻", "🏕️", "🏖️", "🏜️", "🏝️", "🏞️", "🏟️", "🏛️", "🏗️", "🧱", "🏘️", "🏚️", "🏠", "🏡", "🏢", "🏣", "🏤", "🏥", "🏦", "🏨", "🏩", "🏪", "🏫", "🏬", "🏭", "🏯", "🏰", "💒", "🗼", "🗽", "⛪️", "🕌", "🛕", "🕍", "⛩️", "🕋", "⛲️", "⛺️", "🌁", "🌃", "🏙️", "🌄", "🌅", "🌆", "🌇", "🌉", "♨️", "🎠", "🎡", "🎢", "💈", "🎪", "🚂", "🚃", "🚄", "🚅", "🚆", "🚇", "🚈", "🚉", "🚊", "🚝", "🚞", "🚋", "🚌", "🚍", "🚎", "🚐", "🚑", "🚒", "🚓", "🚔", "🚕", "🚖", "🚗", "🚘", "🚙", "🚚", "🚛", "🚜", "🏎️", "🏍️", "🛵", "🦽", "🦼", "🛴", "🚲", "🛺", "🚁", "✈️", "🛩️", "🛫", "🛬", "🪂", "💺", "🚢", "⛴️", "🛥️", "🚤", "⛵️", "🛶", "🚁", "🚟", "🚠", "🚡"],
                "keywords": "travel place location building car plane train bus"
            },
            "Activities & Sports": {
                "emojis": ["⚽️", "🏀", "🏈", "⚾️", "🥎", "🎾", "🏐", "🏉", "🥏", "🎱", "🏓", "🏸", "🏒", "🏑", "🥍", "🏏", "🥅", "⛳️", "🪁", "🏹", "🎣", "🤿", "🥊", "🥋", "🎽", "🛹", "🛷", "⛸️", "🥌", "🎿", "⛷️", "🏂", "🪂", "🏋️‍♀️", "🏋️", "🏋️‍♂️", "🤼‍♀️", "🤼", "🤼‍♂️", "🤸‍♀️", "🤸", "🤸‍♂️", "⛹️‍♀️", "⛹️", "⛹️‍♂️", "🤺", "🤾‍♀️", "🤾", "🤾‍♂️", "🏌️‍♀️", "🏌️", "🏌️‍♂️", "🏇", "🧘‍♀️", "🧘", "🧘‍♂️", "🏄‍♀️", "🏄", "🏄‍♂️", "🏊‍♀️", "🏊", "🏊‍♂️", "🤽‍♀️", "🤽", "🤽‍♂️", "🚣‍♀️", "🚣", "🚣‍♂️", "🧗‍♀️", "🧗", "🧗‍♂️", "🚵‍♀️", "🚵", "🚵‍♂️", "🚴‍♀️", "🚴", "🚴‍♂️", "🏆", "🥇", "🥈", "🥉", "🏅", "🎖️", "🏵️", "🎗️", "🎫", "🎟️", "🎪", "🤹‍♀️", "🤹", "🤹‍♂️"],
                "keywords": "sport activity game exercise fitness ball play"
            },
            "Objects & Tech": {
                "emojis": ["⌚️", "📱", "📲", "💻", "⌨️", "🖥️", "🖨️", "🖱️", "🖲️", "🕹️", "🗜️", "💾", "💿", "📀", "📼", "📷", "📸", "📹", "🎥", "📽️", "🎞️", "📞", "☎️", "📟", "📠", "📺", "📻", "🎙️", "🎚️", "🎛️", "⏱️", "⏲️", "⏰", "🕰️", "⌛️", "⏳", "📡", "🔋", "🔌", "💡", "🔦", "🕯️", "🧯", "🛢️", "💸", "💵", "💴", "💶", "💷", "💰", "💳", "💎", "⚖️", "🪜", "🧰", "🪛", "🔧", "🔨", "⚒️", "🛠️", "⛏️", "🪚", "🔩", "⚙️", "🪤", "🧱", "⛓️", "🧲", "🔫", "💣", "🧨", "🪓", "🔪", "🗡️", "⚔️", "🛡️", "🚬", "⚰️", "🪦", "⚱️", "🏺", "🔮", "📿", "🧿", "💈", "⚗️", "🔭", "🔬", "🕳️", "🩹", "🩺", "💊", "💉", "🩸", "🧬", "🦠", "🧫", "🧪", "🌡️", "🧹", "🪠", "🧺", "🧻", "🚽", "🚰", "🚿", "🛁", "🛀", "🧼", "🪥", "🪒", "🧽", "🪣", "🧴", "🛎️", "🔑", "🗝️", "🚪", "🪑", "🛋️", "🛏️", "🛌", "🧸", "🪆", "🖼️", "🪞", "🪟", "🛍️", "🛒", "🎁", "🎈", "🎏", "🎀", "🪄", "🪅", "🎊", "🎉", "🎎", "🏮", "🎐", "🧧", "✉️", "📩", "📨", "📧", "💌", "📥", "📤", "📦", "🏷️", "🪧", "📪", "📫", "📬", "📭", "📮", "📯", "📜", "📃", "📄", "📑", "🧾", "📊", "📈", "📉", "🗒️", "🗓️", "📆", "📅", "🗑️", "📇", "🗃️", "🗳️", "🗄️", "📋", "📁", "📂", "🗂️", "🗞️", "📰", "📓", "📔", "📒", "📕", "📗", "📘", "📙", "📚", "📖", "🔖", "🧷", "🔗", "📎", "🖇️", "📐", "📏", "🧮", "📌", "📍", "✂️", "🖊️", "🖋️", "✒️", "🖌️", "🖍️", "📝", "✏️", "🔍", "🔎", "🔏", "🔐", "🔒", "🔓"],
                "keywords": "computer phone watch money tech device tool office"
            },
            "Symbols & Signs": {
                "emojis": ["❤️", "🧡", "💛", "💚", "💙", "💜", "🖤", "🤍", "🤎", "💔", "❣️", "💕", "💞", "💓", "💗", "💖", "💘", "💝", "💟", "☮️", "✝️", "☪️", "🕉️", "☸️", "✡️", "🔯", "🕎", "☯️", "☦️", "🛐", "⛎", "♈", "♉", "♊", "♋", "♌", "♍", "♎", "♏", "♐", "♑", "♒", "♓", "🆔", "⚛️", "✅", "☑️", "✔️", "❌", "❎", "➖", "➗", "➕", "➰", "➿", "〽️", "✳️", "✴️", "❇️", "‼️", "⁉️", "❓", "❔", "❕", "❗", "🔅", "🔆", "〰️", "©️", "®️", "™️", "#️⃣", "*️⃣", "0️⃣", "1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟", "🔠", "🔡", "🔢", "🔣", "🔤", "🅰️", "🆎", "🅱️", "🆑", "🆒", "🆓", "ℹ️", "🆔", "Ⓜ️", "🆕", "🆖", "🅾️", "🆗", "🅿️", "🆘", "🆙", "🆚", "🈁", "🈂️", "🈷️", "🈶", "🈯", "🉐", "🈹", "🈲", "🉑", "🈸", "🈴", "🈳", "㊗️", "㊙️", "🈺", "🈵", "🔴", "🟠", "🟡", "🟢", "🔵", "🟣", "⚫", "⚪", "🟤", "🔶", "🔷", "🔸", "🔹", "🔺", "🔻", "💠", "🔘", "🔳", "🔲"],
                "keywords": "heart love symbol star sign zodiac check mark question"
            },
            "Flags": {
                "emojis": ["🏳️", "🏴", "🏁", "🚩", "🏳️‍🌈", "🏳️‍⚧️", "🇺🇳", "🇦🇫", "🇦🇽", "🇦🇱", "🇩🇿", "🇦🇸", "🇦🇩", "🇦🇴", "🇦🇮", "🇦🇶", "🇦🇬", "🇦🇷", "🇦🇲", "🇦🇼", "🇦🇺", "🇦🇹", "🇦🇿", "🇧🇸", "🇧🇭", "🇧🇩", "🇧🇧", "🇧🇾", "🇧🇪", "🇧🇿", "🇧🇯", "🇧🇲", "🇧🇹", "🇧🇴", "🇧🇦", "🇧🇼", "🇧🇷", "🇮🇴", "🇻🇬", "🇧🇳", "🇧🇬", "🇧🇫", "🇧🇮", "🇰🇭", "🇨🇲", "🇨🇦", "🇮🇶", "🇮🇸", "🇮🇷", "🇮🇪", "🇮🇲", "🇮🇱", "🇮🇹", "🇯🇲", "🇯🇵", "🇯🇪", "🇯🇴", "🇰🇿", "🇰🇪", "🇰🇮", "🇰🇼", "🇰🇬", "🇱🇦", "🇱🇻", "🇱🇧", "🇱🇸", "🇱🇷", "🇱🇾", "🇱🇮", "🇱🇹", "🇱🇺", "🇲🇴", "🇲🇬", "🇲🇼", "🇲🇾", "🇲🇻", "🇲🇱", "🇲🇹", "🇲🇭", "🇲🇶", "🇲🇷", "🇲🇺", "🇾🇹", "🇲🇽", "🇫🇲", "🇲🇩", "🇲🇨", "🇲🇳", "🇲🇪", "🇲🇸", "🇲🇦", "🇲🇿", "🇲🇲", "🇳🇦", "🇳🇷", "🇳🇵", "🇳🇱", "🇳🇨", "🇳🇿", "🇳🇮", "🇳🇪", "🇳🇬", "🇳🇺", "🇳🇫", "🇰🇵", "🇲🇰", "🇲🇵", "🇳🇴", "🇴🇲", "🇵🇰", "🇵🇼", "🇵🇸", "🇵🇦", "🇵🇬", "🇵🇾", "🇵🇪", "🇵🇭", "🇵🇳", "🇵🇱", "🇵🇹", "🇵🇷", "🇶🇦", "🇷🇪", "🇷🇴", "🇷🇺", "🇷🇼", "🇼🇸", "🇸🇲", "🇸🇦", "🇸🇳", "🇷🇸", "🇸🇨", "🇸🇱", "🇸🇬", "🇸🇰", "🇸🇮", "🇬🇸", "🇸🇧", "🇸🇴", "🇿🇦", "🇰🇷", "🇸🇸", "🇪🇸", "🇱🇰", "🇧🇱", "🇸🇭", "🇰🇳", "🇱🇨", "🇵🇲", "🇻🇨", "🇸🇩", "🇸🇷", "🇸🇪", "🇨🇭", "🇸🇾", "🇹🇼", "🇹🇯", "🇹🇿", "🇹🇭", "🇹🇱", "🇹🇬", "🇹🇰", "🇹🇴", "🇹🇹", "🇹🇳", "🇹🇷", "🇹🇲", "🇹🇨", "🇹🇻", "🇻🇮", "🇺🇬", "🇺🇦", "🇦🇪", "🇬🇧", "🇺🇸", "🇺🇾", "🇺🇿", "🇻🇺", "🇻🇦", "🇻🇪", "🇻🇳", "🇼🇫", "🇪🇭", "🇾🇪", "🇿🇲", "🇿🇼", "🏴‍☠️"],
                "keywords": "flag country nation world country"
            },
            "Weather & Nature": {
                "emojis": ["☀️", "🌤️", "⛅️", "🌥️", "☁️", "🌦️", "🌧️", "⛈️", "🌩️", "⚡️", "☔️", "❄️", "☃️", "⛄️", "🌨️", "💨", "💧", "💦", "☂️", "☔️", "🌊", "🌫️", "🔥", "⭐", "🌟", "💫", "✨", "⚡", "☄️", "💥", "🌙", "🌚", "🌛", "🌜", "🌑", "🌒", "🌓", "🌔", "🌕", "🌖", "🌗", "🌘", "🌍", "🌎", "🌏", "🌐", "🗺️", "🧭", "🏔️", "⛰️", "🌋", "🗻", "🏕️", "🏖️", "🏜️", "🏝️", "🏞️", "🌲", "🌳", "🌴", "🌵", "🌾", "🌿", "☘️", "🍀", "🍁", "🍂", "🍃", "🌺", "🌻", "🌹", "🌷", "🌱", "🌼", "🌸", "💐", "🌾", "🌷", "🥀", "🌹", "🌻", "🌺", "🌼", "🌸", "🌿", "🌱", "🍃", "🍂", "🍁", "🍀", "☘️"],
                "keywords": "weather sun rain snow cloud star moon earth nature"
            },
        }
        
        dialog = QDialog(self)
        dialog.setWindowTitle("😊 Emoji Picker")
        dialog.setMinimumSize(450, 600)
        dialog.setMaximumSize(600, 700)
        dialog.setStyleSheet("""
            QDialog {
                background-color: #333;
            }
        """)
        
        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setSpacing(10)
        
        # Title
        title = QLabel("Select an emoji:")
        title.setStyleSheet("font-size: 16px; font-weight: 600; color: #FFF; margin-bottom: 5px;")
        layout.addWidget(title)
        
        # Search box
        search_box = QLineEdit()
        search_box.setPlaceholderText("🔍 Search emojis...")
        search_box.setStyleSheet("""
            QLineEdit {
                background-color: #222;
                color: #FFF;
                border: 2px solid #555;
                border-radius: 6px;
                padding: 8px;
                font-size: 14px;
            }
            QLineEdit:focus {
                border: 2px solid #0078D7;
            }
        """)
        layout.addWidget(search_box)
        
        # Emoji list
        list_widget = QListWidget()
        list_widget.setStyleSheet("""
            QListWidget {
                background-color: #222;
                color: #FFF;
                border: 1px solid #555;
                border-radius: 4px;
                font-size: 20px;
                padding: 5px;
            }
            QListWidget::item {
                padding: 8px;
                border-bottom: 1px solid #333;
                min-height: 45px;
            }
            QListWidget::item:hover {
                background-color: #444;
            }
            QListWidget::item:selected {
                background-color: #0078D7;
            }
        """)
        
        # Store all emoji items with their data for filtering
        all_items = []
        
        def get_emoji_name(emoji, category):
            """Get the name for an emoji, with fallback generation"""
            return generate_emoji_name(emoji, category)
        
        def populate_list(filter_text=""):
            """Populate the list with emojis, optionally filtered"""
            nonlocal all_items, list_widget
            list_widget.clear()
            all_items.clear()
            filter_lower = filter_text.lower().strip()
            
            for category, data in emojis_data.items():
                emoji_list = data["emojis"]
                keywords = data["keywords"]
                
                # Filter emojis by name if search text provided
                filtered_emojis = []
                if filter_lower:
                    for emoji in emoji_list:
                        emoji_name = get_emoji_name(emoji, category).lower()
                        # Check if search matches emoji name, category, keywords, or the emoji itself
                        if (filter_lower in emoji_name or 
                            filter_lower in category.lower() or 
                            filter_lower in keywords.lower() or
                            filter_lower in emoji):
                            filtered_emojis.append(emoji)
                else:
                    filtered_emojis = emoji_list
                
                # Only show category if there are emojis to show
                if filtered_emojis:
                    # Add category header
                    category_item = QListWidgetItem(f"  {category}")
                    # Disable selection and enable for category headers
                    from PyQt6.QtCore import Qt
                    category_item.setFlags(category_item.flags() & ~Qt.ItemFlag.ItemIsSelectable & ~Qt.ItemFlag.ItemIsEnabled)
                    category_item.setBackground(QColor(80, 80, 80))
                    category_item.setForeground(QColor(200, 200, 200))
                    list_widget.addItem(category_item)
                    all_items.append(category_item)
                    
                    # Add emojis in this category with their names
                    for emoji in filtered_emojis:
                        emoji_name = get_emoji_name(emoji, category)
                        # Display emoji with name (smaller font for name)
                        emoji_item = QListWidgetItem(f"{emoji}  {emoji_name}")
                        emoji_item.setData(Qt.ItemDataRole.UserRole, emoji)
                        emoji_item.setData(Qt.ItemDataRole.UserRole + 1, category)  # Store category
                        emoji_item.setData(Qt.ItemDataRole.UserRole + 2, emoji_name)  # Store name
                        list_widget.addItem(emoji_item)
                        all_items.append(emoji_item)
        
        # Initial population
        populate_list()
        
        # Search functionality
        def on_search_changed(text):
            populate_list(text)
        
        search_box.textChanged.connect(on_search_changed)
        
        # Buttons
        buttons = QHBoxLayout()
        
        def insert_emoji():
            current_item = list_widget.currentItem()
            if current_item:
                emoji = current_item.data(Qt.ItemDataRole.UserRole)
                if emoji:
                    # Insert emoji at cursor position
                    cursor = self.input_box.textCursor()
                    cursor.insertText(emoji)
                    self.input_box.setTextCursor(cursor)
                    dialog.accept()
        
        list_widget.itemDoubleClicked.connect(insert_emoji)
        
        # Allow Enter key to insert selected emoji
        def on_enter_pressed():
            insert_emoji()
        
        search_box.returnPressed.connect(lambda: list_widget.setFocus() if list_widget.count() > 0 else None)
        list_widget.itemActivated.connect(insert_emoji)
        
        insert_btn = QPushButton("Insert")
        insert_btn.clicked.connect(insert_emoji)
        insert_btn.setStyleSheet("background-color: #0078D7; padding: 8px 16px; border-radius: 4px; font-weight: 600; font-size: 14px;")
        buttons.addWidget(insert_btn)
        
        buttons.addStretch()
        
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(dialog.accept)
        close_btn.setStyleSheet("background-color: #555; padding: 8px 16px; border-radius: 4px; font-size: 14px;")
        buttons.addWidget(close_btn)
        
        layout.addWidget(list_widget, stretch=1)
        layout.addLayout(buttons)
        
        # Set focus to search box
        search_box.setFocus()
        
        dialog.exec()
    
    def clear_conversation(self):
        reply = QMessageBox.question(self, "Clear", "Clear conversation?",
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            self.message_history = []
            self.chat_display.clear()
            self.current_file_content = None
            self.current_file_path = None
            self.file_label.setText("")
            self._save_history()
            self.append_message("system", "Conversation cleared")
    
    def on_mode_changed(self, mode):
        self.current_mode = mode
        # Set the best model for this mode (optimized for effectiveness)
        best_model = DEFAULT_MODEL_PER_MODE.get(mode, "GPT-4o")
        self.current_model = best_model
        # Ensure the model exists in combo box, if not use GPT-4o as fallback
        available_models = [self.model_combo.itemText(i) for i in range(self.model_combo.count())]
        if best_model not in available_models:
            # Fallback to GPT-4o if the recommended model isn't available
            best_model = "GPT-4o"
            if best_model not in available_models:
                # Last resort: use first available model
                best_model = available_models[0] if available_models else "GPT-4o"
        self.model_combo.setCurrentText(best_model)
        self.current_model = best_model  # Update current model to the actual selected one
        self.append_message("system", f"Switched to: {mode} (Optimized Model: {best_model})")
        self._save_history()
    
    def on_model_changed(self, model):
        self.current_model = model
        self._save_history()
    
    # Messaging
    def append_message(self, kind: str, text: str):
        try:
            if not text:
                text = "(empty message)"
            
            # Show full text
            if kind == "user":
                label, color = "Dre", self.USER_COLOR
            elif kind == "assistant":
                label, color = "Lea", self.ASSIST_COLOR
            else:
                label, color = "System", self.SYSTEM_COLOR

            # Ensure text is always a string and safe for HTML
            safe = html.escape(str(text)).replace("\n", "<br>")
            html_block = f'<div style="margin: 6px 0;"><span style="color:{color}; font-weight:600;">{label}:</span> <span style="color:{color};">{safe}</span></div>'
            
            # Ensure we're on the main thread (Qt requirement)
            if hasattr(self, 'chat_display') and self.chat_display:
                self.chat_display.append(html_block)
                
                # Auto-scroll to bottom to show latest message
                scrollbar = self.chat_display.verticalScrollBar()
                scrollbar.setValue(scrollbar.maximum())
        except Exception as e:
            logging.error(f"Error appending message: {traceback.format_exc()}")
            # Fallback to plain text if HTML fails
            try:
                if hasattr(self, 'chat_display') and self.chat_display:
                    self.chat_display.append(f"{label}: {str(text)}")
            except:
                pass
    
    def on_send(self):
        """Send message - simplified non-streaming approach like working version"""
        text = self.input_box.toPlainText().strip()
        if not text or not openai_client:
            return
        
        self.append_message("user", text)
        self.input_box.clear()
        self._update_conversation_status("Thinking...", "thinking")
        
        # Build prompt like working version
        parts = []
        
        # Include knowledge base if checked (if available in your version)
        # Note: This may need adjustment based on your knowledge base implementation
        
        # Include file if checked
        if hasattr(self, 'include_file_cb') and self.include_file_cb.isChecked() and self.current_file_content:
            parts.append(f"=== UPLOADED FILE ===\n{self.current_file_content}\n=== END FILE ===\n")
        
        parts.append(f"Dre's question:\n{text}")
        
        full_prompt = "\n".join(parts)
        self.message_history.append({"role": "user", "content": full_prompt})
        
        system_prompt = AGENTS[self.current_mode]["system_prompt"]
        messages = [{"role": "system", "content": system_prompt}] + self.message_history
        
        try:
            # Chat model - standard parameters
            model_name = MODEL_OPTIONS[self.current_model]
            api_params = {
                "model": model_name,
                "messages": messages,
                "max_tokens": 4096,
                "timeout": 60.0
            }
            
            # Some models (like GPT-5, GPT-5.1, o1, o3, o4) may have different temperature requirements
            # Only set temperature for models that support custom values
            model_lower = model_name.lower()
            if not (model_lower.startswith("gpt-5") or model_lower.startswith("o1-") or 
                    model_lower.startswith("o3-") or model_lower.startswith("o4-")):
                api_params["temperature"] = 0.7
            
            response = openai_client.chat.completions.create(**api_params)
            answer = response.choices[0].message.content
        except Exception as e:
            answer = f"[Error: {e}]"
            logging.error(f"API error: {traceback.format_exc()}")
        
        self.message_history.append({"role": "assistant", "content": answer})
        self.append_message("assistant", answer)
        self._update_conversation_status("Ready", "ready")
        self._save_history()
        
        # Speak the response if TTS is enabled (after response is fully displayed)
        if self.tts_enabled and TTS_AVAILABLE:
            self.speak_text(answer)

    def on_stream_chunk(self, chunk: str):
        """Handle streaming response chunks - removes and recreates last block for reliability"""
        # CRITICAL: Only process if we're actually streaming and this chunk is for current request
        if not self.is_streaming:
            return  # Ignore chunks from old/stopped requests
        
        # Accumulate the full response
        self.current_streaming_response += chunk
        
        try:
            # Get current HTML
            current_html = self.chat_display.toHtml()
            
            # Find the LAST occurrence of "Lea:" marker (our streaming message)
            marker = f'<span style="color:{self.ASSIST_COLOR}; font-weight:600;">Lea:</span>'
            last_marker_pos = current_html.rfind(marker)
            
            if last_marker_pos >= 0:
                # Find the <div> that contains this marker
                # Look backwards from marker to find the opening <div>
                div_start = current_html.rfind('<div', 0, last_marker_pos)
                
                if div_start >= 0:
                    # Find the closing </div> for this block
                    # The structure is: <div>...<span>Lea:</span> <span>content</span></div>
                    # We need to find the SECOND </span> (the one closing content) followed by </div>
                    search_start = last_marker_pos
                    
                    # Find first </span> (closes "Lea:")
                    first_span_close = current_html.find('</span>', search_start)
                    if first_span_close > 0:
                        # Find second </span> (closes content) - search after first one
                        second_span_close = current_html.find('</span>', first_span_close + 7)  # +7 for "</span>"
                        
                        if second_span_close > 0:
                            # Find the </div> that follows the second </span>
                            div_close_pos = current_html.find('</div>', second_span_close)
                            
                            if div_close_pos > 0:
                                # Remove the old block and replace with updated one
                                before = current_html[:div_start]
                                after = current_html[div_close_pos + 6:]  # +6 for "</div>"
                                
                                # Create new block with full accumulated response
                                safe_response = html.escape(self.current_streaming_response).replace("\n", "<br>")
                                new_block = f'<div style="margin: 6px 0;"><span style="color:{self.ASSIST_COLOR}; font-weight:600;">Lea:</span> <span style="color:{self.ASSIST_COLOR};">{safe_response}</span></div>'
                                
                                new_html = before + new_block + after
                                
                                # Update display
                                self.chat_display.setHtml(new_html)
                                
                                # Mark as started
                                if not self.streaming_message_started:
                                    self.streaming_message_started = True
                                
                                # Scroll to bottom
                                scrollbar = self.chat_display.verticalScrollBar()
                                scrollbar.setValue(scrollbar.maximum())
                                return
            
            # If marker not found, create new message (first chunk)
            if not self.streaming_message_started:
                self.streaming_message_started = True
                safe_text = html.escape(self.current_streaming_response).replace("\n", "<br>") if self.current_streaming_response else ""
                new_block = f'<div style="margin: 6px 0;"><span style="color:{self.ASSIST_COLOR}; font-weight:600;">Lea:</span> <span style="color:{self.ASSIST_COLOR};">{safe_text}</span></div>'
                self.chat_display.append(new_block)
                
                scrollbar = self.chat_display.verticalScrollBar()
                scrollbar.setValue(scrollbar.maximum())
            
        except Exception as e:
            logging.error(f"Error in stream chunk: {traceback.format_exc()}")
            # On error, try simple append if not started
            if not self.streaming_message_started and self.current_streaming_response:
                try:
                    self.streaming_message_started = True
                    safe_text = html.escape(self.current_streaming_response).replace("\n", "<br>")
                    new_block = f'<div style="margin: 6px 0;"><span style="color:{self.ASSIST_COLOR}; font-weight:600;">Lea:</span> <span style="color:{self.ASSIST_COLOR};">{safe_text}</span></div>'
                    self.chat_display.append(new_block)
                except:
                    pass
    
    def on_memory_context(self, context_msg: str):
        """Handle memory context information"""
        try:
            # Optionally show memory context in status or log it
            logging.info(f"Memory context: {context_msg}")
            # You could also show this in the UI if desired
        except Exception as e:
            logging.warning(f"Error handling memory context: {e}")
    
    def on_worker_finished(self, answer, status):
        try:
            # If we were streaming, ensure final message is displayed correctly with full text
            if self.is_streaming and self.current_streaming_response:
                # Force final update of streaming message to ensure it's complete
                final_text = self.current_streaming_response.strip()
                if final_text:
                    safe_text = html.escape(final_text).replace("\n", "<br>")
                    html_content = self.chat_display.toHtml()
                    lea_pattern = f'<span style="color:{self.ASSIST_COLOR}; font-weight:600;">Lea:</span>'
                    
                    if lea_pattern in html_content:
                        # Use same simple approach as in on_stream_chunk
                        parts = html_content.rsplit(lea_pattern, 1)
                        if len(parts) == 2:
                            after_lea_content = parts[1]
                            div_end_pos = after_lea_content.find('</div>')
                            
                            if div_end_pos > 0:
                                before = parts[0] + lea_pattern
                                after = after_lea_content[div_end_pos:]
                                new_content = f' <span style="color:{self.ASSIST_COLOR};">{safe_text}</span>'
                                new_html = before + new_content + after
                                try:
                                    self.chat_display.setHtml(new_html)
                                except:
                                    pass
            
            self.is_streaming = False
            self.streaming_message_started = False
            
            # If we were streaming, use the accumulated response
            # The message is already displayed via chunks, but we need to ensure it's saved
            if self.current_streaming_response:
                # Use the accumulated streaming response if available
                final_answer = self.current_streaming_response.strip()
                # Make sure it's saved to history if it wasn't already
                if final_answer and self.message_history:
                    # Check if the last message is an assistant message with this content
                    last_msg = self.message_history[-1] if self.message_history else None
                    if not (last_msg and last_msg.get('role') == 'assistant' and last_msg.get('content') == final_answer):
                        # Update or add the assistant response
                        if last_msg and last_msg.get('role') == 'assistant':
                            # Update existing
                            self.message_history[-1]['content'] = final_answer
                        else:
                            # Add new
                            self.message_history.append({"role": "assistant", "content": final_answer})
            elif answer:
                # Non-streaming mode - message should already be in history, but ensure it's there
                if not self.message_history or self.message_history[-1].get('role') != 'assistant':
                    self.append_message("assistant", str(answer))
                    # Ensure it's in history
                    if not (self.message_history and self.message_history[-1].get('role') == 'assistant'):
                        self.message_history.append({"role": "assistant", "content": str(answer)})
            
            # Limit history to configured max
            if len(self.message_history) > self.max_history_messages:
                self.message_history = self.message_history[-self.max_history_messages:]
            
            # Reset streaming state for next time
            self.current_streaming_response = ""
            
            # Reset status label style and show appropriate status
            self._update_conversation_status(str(status) if status else "Ready", "ready")
            
            # Always save history after receiving a response
            self._save_history()
            # Clean up references after successful completion
            try:
                if hasattr(self, '_current_worker'):
                    self._current_worker = None
            except:
                pass
        except Exception as e:
            logging.error(f"Error in on_worker_finished: {traceback.format_exc()}")
            try:
                self._update_conversation_status("Error displaying response", "error")
            except:
                pass
    
    def on_worker_error(self, error_msg):
        try:
            error_text = str(error_msg) if error_msg else "Unknown error"
            self.append_message("system", f"❌ Error: {error_text}")
            self._update_conversation_status("Error", "error")
            # Show user-friendly error dialog
            QMessageBox.warning(self, "Error", 
                              f"An error occurred:\n\n{error_text}\n\nCheck lea_crash.log for details.")
            
            # Clean up references after error
            try:
                if hasattr(self, '_current_worker'):
                    self._current_worker = None
            except:
                pass
        except Exception as e:
            logging.error(f"Error in on_worker_error: {traceback.format_exc()}")
            try:
                self._update_conversation_status("Error handling failed", "error")
            except:
                pass
    
    def _save_history(self):
        try:
            # Ensure message_history is a list
            if not isinstance(self.message_history, list):
                self.message_history = []
            
            # Use absolute path in project directory
            history_path = PROJECT_DIR / self.history_file
            # Limit history to last 20 messages
            history = self.message_history[-self.max_history_messages:] if len(self.message_history) > self.max_history_messages else self.message_history.copy()
            
            data = {
                'mode': str(self.current_mode) if self.current_mode else '',
                'model': str(self.current_model) if self.current_model else '',
                'history': history
            }
            
            # Try to save, with better error handling
            try:
                with open(history_path, 'w', encoding='utf-8') as f:
                    json.dump(data, f, indent=2, ensure_ascii=False)
            except PermissionError:
                # If permission denied, try alternative location
                try:
                    alt_path = Path.home() / "lea_history.json"
                    with open(alt_path, 'w', encoding='utf-8') as f:
                        json.dump(data, f, indent=2, ensure_ascii=False)
                    logging.info(f"Saved history to {alt_path} due to permission issue")
                except Exception as e2:
                    logging.warning(f"Could not save history to alternative location: {e2}")
            except OSError as os_err:
                logging.warning(f"File system error saving history: {os_err}")
        except Exception as e:
            logging.error(f"Error saving history: {traceback.format_exc()}")
    
    def _load_history(self):
        try:
            # Try project directory first
            history_path = PROJECT_DIR / self.history_file
            # Fallback to home directory if needed
            if not history_path.exists():
                alt_path = Path.home() / "lea_history.json"
                if alt_path.exists():
                    history_path = alt_path
            
            if not history_path.exists():
                msg = "Welcome to Lea Multi-Agent System!\n\n"
                msg += f"💾 Backups: {BACKUPS_DIR}\n"
                msg += f"📥 Downloads: {DOWNLOADS_DIR}\n\n"
                msg += "📎 Upload files when you need to reference them\n"
                msg += "📥 Download Lea's responses to save them\n"
                msg += "🔍 Lea can search the web for current information\n\n"
                # Check if web search is configured
                if os.getenv("SERPAPI_API_KEY"):
                    msg += "✅ Web search enabled"
                else:
                    msg += "⚠️ Web search not configured (add SERPAPI_API_KEY to .env)"
                self.append_message("system", msg)
                return
            
            try:
                with open(history_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                # Validate loaded data
                if not isinstance(data, dict):
                    logging.warning(f"Invalid history file format: {history_path}")
                    return
                
                # Load mode and model with validation
                loaded_mode = data.get('mode', "General Assistant & Triage")
                if loaded_mode in AGENTS:
                    self.current_mode = loaded_mode
                else:
                    logging.warning(f"Invalid mode in history: {loaded_mode}")
                
                loaded_model = data.get('model', "GPT-4o")
                if loaded_model in MODEL_OPTIONS:
                    self.current_model = loaded_model
                else:
                    logging.warning(f"Invalid model in history: {loaded_model}")
                
                # Load history with validation
                loaded_history = data.get('history', [])
                if isinstance(loaded_history, list):
                    self.message_history = loaded_history
                    # Limit history to last 20 messages
                    if len(self.message_history) > 20:
                        self.message_history = self.message_history[-20:]
                else:
                    logging.warning("Invalid history format in file")
                    self.message_history = []
                
                # Update UI safely
                try:
                    if hasattr(self, 'mode_combo'):
                        self.mode_combo.setCurrentText(self.current_mode)
                    if hasattr(self, 'model_combo'):
                        self.model_combo.setCurrentText(self.current_model)
                    self.append_message("system", f"Loaded previous conversation ({len(self.message_history)} messages)")
                    
                    # Display ALL messages from history (not just last 5)
                    for msg in self.message_history:
                        if not isinstance(msg, dict):
                            continue
                        role = msg.get('role')
                        content = msg.get('content', '')
                        if not content:
                            continue
                        try:
                            # Clean up user messages that have file content prefixes
                            if role == 'user' and 'Dre\'s question:' in str(content):
                                # Extract just the user's question part
                                content = str(content).split('Dre\'s question:')[-1].strip()
                                # Also remove file content if present
                                if '=== UPLOADED FILE' in content:
                                    parts = content.split('=== END FILE ===')
                                    if len(parts) > 1:
                                        content = parts[-1].strip()
                                        if content.startswith('Dre\'s question:'):
                                            content = content.replace('Dre\'s question:', '').strip()
                            
                            # Display the message
                            if role == 'user':
                                self.append_message('user', content)
                            elif role == 'assistant':
                                self.append_message('assistant', content)
                            # Skip system messages in history (they're internal)
                        except Exception as msg_error:
                            logging.warning(f"Error displaying message: {msg_error}")
                            continue
                    
                    # Scroll to bottom after loading all history messages
                    if hasattr(self, 'chat_display') and self.chat_display:
                        scrollbar = self.chat_display.verticalScrollBar()
                        scrollbar.setValue(scrollbar.maximum())
                except Exception as ui_error:
                    logging.error(f"Error updating UI: {ui_error}")
                    
            except json.JSONDecodeError as json_err:
                logging.error(f"Invalid JSON in history file: {json_err}")
                # Show welcome message instead
                self.append_message("system", "Welcome! (Previous conversation could not be loaded)")
            except PermissionError:
                logging.warning(f"Permission denied reading history: {history_path}")
            except OSError as os_err:
                logging.warning(f"File system error reading history: {os_err}")
                
        except Exception as e:
            logging.error(f"Error loading history: {traceback.format_exc()}")
            # Continue with defaults
            self.append_message("system", "Welcome! (Error loading previous conversation)")
    
    def load_settings(self):
        """Load settings from file"""
        try:
            if self.settings_file.exists():
                with open(self.settings_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    # Settings loading (no TTS settings)
        except Exception as e:
            logging.warning(f"Error loading settings: {e}")
            # Use defaults
    
    def save_settings(self):
        """Save settings to file"""
        try:
            data = {}
            with open(self.settings_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            logging.warning(f"Error saving settings: {e}")
    
    def _update_tts_mic_status(self):
        """Update TTS/Microphone status indicator"""
        if not hasattr(self, 'tts_mic_status'):
            return
        
        if self.is_listening:
            # Listening (green)
            self.tts_mic_status.setText("🟢 TTS/Mic: Listening")
            self.tts_mic_status.setStyleSheet("""
                QLabel {
                    color: #68BD47;
                    font-size: 12px;
                    font-weight: 600;
                    padding: 4px 8px;
                    background-color: #2a2a2a;
                    border-radius: 4px;
                }
            """)
        elif self.tts_enabled:
            # TTS active but not listening (green)
            self.tts_mic_status.setText("🟢 TTS/Mic: Active")
            self.tts_mic_status.setStyleSheet("""
                QLabel {
                    color: #68BD47;
                    font-size: 12px;
                    font-weight: 600;
                    padding: 4px 8px;
                    background-color: #2a2a2a;
                    border-radius: 4px;
                }
            """)
        else:
            # Inactive (red)
            self.tts_mic_status.setText("🔴 TTS/Mic: Inactive")
            self.tts_mic_status.setStyleSheet("""
                QLabel {
                    color: #FF4444;
                    font-size: 12px;
                    font-weight: 600;
                    padding: 4px 8px;
                    background-color: #2a2a2a;
                    border-radius: 4px;
                }
            """)
    
    def _update_conversation_status(self, status: str, state: str = "ready"):
        """
        Update conversation status indicator
        state: 'ready' (green), 'thinking' (yellow), 'error' (red), 'processing' (blue)
        """
        if not hasattr(self, 'conversation_status'):
            return
        
        color_map = {
            "ready": "#68BD47",      # Green
            "thinking": "#FFB020",   # Yellow/Orange
            "processing": "#2DBCEE", # Blue
            "error": "#FF4444",      # Red
            "listening": "#9B59B6"   # Purple (for speech recognition)
        }
        
        color = color_map.get(state, "#DDD")
        self.conversation_status.setText(status)
        self.conversation_status.setStyleSheet(f"""
            QLabel {{
                color: {color};
                font-size: 12px;
                font-weight: 600;
                padding: 4px 8px;
                background-color: #2a2a2a;
                border-radius: 4px;
            }}
        """)
    
    def toggle_tts(self):
        """Toggle TTS on/off"""
        self.tts_enabled = not self.tts_enabled
        if hasattr(self, 'tts_btn'):
            if self.tts_enabled:
                self.tts_btn.setText("🔊 TTS On")
                self.tts_btn.setChecked(True)
            else:
                self.tts_btn.setText("🔇 TTS Off")
                self.tts_btn.setChecked(False)
        self._update_tts_mic_status()
    
    def speak_text(self, text: str):
        """Speak text using gTTS in a separate thread to avoid blocking"""
        if not TTS_AVAILABLE or not PYGAME_AVAILABLE:
            # Update status to show TTS error
            self._update_tts_mic_status()
            return
        
        def speak_in_thread():
            try:
                # Clean text - remove markdown, code blocks, etc.
                clean_text = text
                # Remove code blocks
                import re
                clean_text = re.sub(r'```[\s\S]*?```', '', clean_text)
                # Remove inline code
                clean_text = re.sub(r'`[^`]+`', '', clean_text)
                # Remove markdown links
                clean_text = re.sub(r'\[([^\]]+)\]\([^\)]+\)', r'\1', clean_text)
                # Remove extra whitespace
                clean_text = ' '.join(clean_text.split())
                
                if not clean_text or len(clean_text) < 3:
                    return
                
                # Limit length to avoid very long audio
                if len(clean_text) > 500:
                    clean_text = clean_text[:500] + "..."
                
                # Create gTTS object
                tts = gTTS(text=clean_text, lang=self.tts_voice_lang, tld=self.tts_voice_tld, slow=False)
                
                # Save to temporary file
                with tempfile.NamedTemporaryFile(delete=False, suffix='.mp3') as tmp_file:
                    tmp_path = tmp_file.name
                    tts.save(tmp_path)
                
                # Play using pygame
                pygame.mixer.init()
                pygame.mixer.music.load(tmp_path)
                pygame.mixer.music.play()
                
                # Wait for playback to finish
                while pygame.mixer.music.get_busy():
                    time.sleep(0.1)
                
                # Clean up
                pygame.mixer.quit()
                try:
                    os.unlink(tmp_path)
                except:
                    pass
                    
            except Exception as e:
                logging.warning(f"TTS error: {e}")
                # Update status and show error popup
                self._update_tts_mic_status()
                QMessageBox.warning(self, "TTS Error", 
                                   f"Text-to-Speech Error:\n\n{e}\n\n"
                                   f"TTS Status: {'Enabled' if self.tts_enabled else 'Disabled'}")
        
        # Run in separate thread to avoid blocking UI
        import threading
        thread = threading.Thread(target=speak_in_thread, daemon=True)
        thread.start()
    
    def show_coordinate_finder(self):
        """Show coordinate finder tool to help find screen coordinates"""
        if not TASK_SYSTEM_AVAILABLE:
            QMessageBox.information(self, "Not Available", "Task system not available")
            return
        
        try:
            import pyautogui
        except ImportError:
            QMessageBox.warning(self, "Missing Library", 
                               "pyautogui not installed.\n\nInstall with: pip install pyautogui")
            return
        
        # Create a simple floating window that shows coordinates
        coord_window = QDialog(self)
        coord_window.setWindowTitle("📍 Coordinate Finder - Press ESC to close")
        coord_window.setWindowFlags(Qt.WindowType.WindowStaysOnTopHint)
        coord_window.setMinimumSize(300, 150)
        coord_window.setStyleSheet("""
            QDialog {
                background-color: #222;
                border: 2px solid #68BD47;
            }
            QLabel {
                color: #68BD47;
                font-size: 18px;
                font-weight: 600;
                padding: 10px;
            }
        """)
        
        layout = QVBoxLayout(coord_window)
        layout.setContentsMargins(15, 15, 15, 15)
        
        # Get screen size
        screen_width, screen_height = pyautogui.size()
        screen_info = QLabel(f"Screen Size: {screen_width} x {screen_height}")
        screen_info.setStyleSheet("color: #2DBCEE; font-size: 12px;")
        layout.addWidget(screen_info)
        
        # Coordinate display
        coord_label = QLabel("Move mouse to see coordinates...")
        coord_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(coord_label)
        
        # Instructions
        instructions = QLabel("Click 'Copy' to copy coordinates\nPress ESC to close")
        instructions.setStyleSheet("color: #FFF; font-size: 11px;")
        instructions.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(instructions)
        
        # Copy button
        copy_btn = QPushButton("Copy Coordinates")
        copy_btn.clicked.connect(lambda: self._copy_coordinates(pyautogui, coord_label))
        copy_btn.setStyleSheet("""
            QPushButton {
                background-color: #68BD47;
                color: #FFF;
                border: none;
                border-radius: 4px;
                padding: 8px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #5aa03a;
            }
        """)
        layout.addWidget(copy_btn)
        
        # Timer to update coordinates
        from PyQt6.QtCore import QTimer
        timer = QTimer()
        def update_coordinates():
            try:
                x, y = pyautogui.position()
                coord_label.setText(f"X: {x}  |  Y: {y}")
            except:
                pass
        timer.timeout.connect(update_coordinates)
        timer.start(100)  # Update every 100ms
        
        # Handle ESC key
        def keyPressEvent(event):
            if event.key() == Qt.Key.Key_Escape:
                timer.stop()
                coord_window.close()
        coord_window.keyPressEvent = keyPressEvent
        
        # Position window in top-right corner
        screen = QApplication.primaryScreen().geometry()
        coord_window.move(screen.width() - 320, 50)
        
        coord_window.exec()
        timer.stop()
    
    def _copy_coordinates(self, pyautogui, coord_label):
        """Copy current mouse coordinates to clipboard"""
        try:
            x, y = pyautogui.position()
            from PyQt6.QtGui import QClipboard
            clipboard = QApplication.clipboard()
            clipboard.setText(f"{x}, {y}")
            coord_label.setText(f"✅ Copied: {x}, {y}")
            coord_label.setStyleSheet("color: #68BD47; font-size: 18px; font-weight: 600; padding: 10px;")
            QMessageBox.information(self, "Copied", f"Coordinates copied to clipboard:\nX: {x}, Y: {y}")
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Could not get coordinates: {e}")
    
    def show_settings(self):
        """Show settings dialog"""
        if TTS_AVAILABLE:
            dialog = QDialog(self)
            dialog.setWindowTitle("⚙️ TTS Settings")
            dialog.setMinimumSize(300, 200)
            dialog.setStyleSheet("""
                QDialog {
                    background-color: #333;
                }
            """)
            
            layout = QVBoxLayout(dialog)
            layout.setContentsMargins(20, 20, 20, 20)
            layout.setSpacing(15)
            
            title = QLabel("Text-to-Speech Settings")
            title.setStyleSheet("font-size: 18px; font-weight: 600; color: #FFF; margin-bottom: 10px;")
            layout.addWidget(title)
            
            tts_toggle = QCheckBox("Enable TTS")
            tts_toggle.setChecked(self.tts_enabled)
            tts_toggle.toggled.connect(lambda checked: setattr(self, 'tts_enabled', checked))
            tts_toggle.setStyleSheet("color: #FFF; font-size: 14px;")
            layout.addWidget(tts_toggle)
            
            layout.addStretch()
            
            buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok)
            buttons.accepted.connect(dialog.accept)
            buttons.setStyleSheet("""
                QPushButton {
                    background-color: #0078D7;
                    color: #FFF;
                    border: none;
                    border-radius: 4px;
                    padding: 8px 20px;
                    font-size: 14px;
                }
                QPushButton:hover {
                    background-color: #106ebe;
                }
            """)
            layout.addWidget(buttons)
            
            dialog.exec()
        else:
            QMessageBox.information(self, "Settings", "TTS is not available. Install with: pip install gtts pygame")
    
    def toggle_speech_recognition(self):
        """Toggle speech recognition on/off"""
        if not SPEECH_RECOGNITION_AVAILABLE:
            QMessageBox.information(self, "Speech Recognition", 
                                   "Speech recognition not available. Install with: pip install SpeechRecognition")
            return
        
        if self.is_listening:
            # Stop listening
            self.is_listening = False
            if hasattr(self, 'mic_btn'):
                self.mic_btn.setText("🎤")
                self.mic_btn.setStyleSheet("background-color: #444; font-size: 20px; border-radius: 4px; padding: 4px;")
            self._update_conversation_status("Ready", "ready")
            self._update_tts_mic_status()
            return
        
        # Start listening
        if not self.speech_recognizer:
            try:
                self.speech_recognizer = sr.Recognizer()
            except Exception as e:
                QMessageBox.warning(self, "Error", f"Could not initialize speech recognizer: {e}")
                return
        
        # Check if microphone is set up
        if self.microphone_device_index is None:
            self._setup_microphone_first_time()
            return
        
        # Start speech recognition in a thread
        self.is_listening = True
        if hasattr(self, 'mic_btn'):
            self.mic_btn.setText("🔴")
            self.mic_btn.setStyleSheet("background-color: #D13438; font-size: 20px; border-radius: 4px; padding: 4px;")
        self._update_conversation_status("Listening...", "listening")
        self._update_tts_mic_status()
        
        # Create worker thread
        self.speech_worker_thread = QThread()
        self.speech_worker = SpeechRecognitionWorker(self.speech_recognizer, self.microphone_device_index)
        self.speech_worker.moveToThread(self.speech_worker_thread)
        
        # Connect signals
        self.speech_worker_thread.started.connect(self.speech_worker.run)
        self.speech_worker.finished.connect(self.on_speech_recognition_finished)
        self.speech_worker.error.connect(self.on_speech_recognition_error)
        self.speech_worker.listening.connect(self.on_speech_listening)
        
        # Start thread
        self.speech_worker_thread.start()
    
    def _setup_microphone_first_time(self):
        """Setup microphone device selection on first use"""
        if not SPEECH_RECOGNITION_AVAILABLE:
            return
        
        try:
            # Get list of microphones
            mic_list = sr.Microphone.list_microphone_names()
            
            if not mic_list:
                QMessageBox.warning(self, "No Microphone", "No microphones found on your system.")
                return
            
            # Show selection dialog
            dialog = QDialog(self)
            dialog.setWindowTitle("Select Microphone")
            dialog.setMinimumSize(400, 300)
            dialog.setStyleSheet("""
                QDialog {
                    background-color: #333;
                }
            """)
            
            layout = QVBoxLayout(dialog)
            layout.setContentsMargins(20, 20, 20, 20)
            layout.setSpacing(15)
            
            title = QLabel("Select your microphone:")
            title.setStyleSheet("font-size: 16px; font-weight: 600; color: #FFF;")
            layout.addWidget(title)
            
            from PyQt6.QtWidgets import QListWidget
            mic_list_widget = QListWidget()
            mic_list_widget.addItems(mic_list)
            mic_list_widget.setStyleSheet("""
                QListWidget {
                    background-color: #222;
                    color: #FFF;
                    border: 1px solid #555;
                    border-radius: 4px;
                    padding: 5px;
                }
                QListWidget::item {
                    padding: 8px;
                }
                QListWidget::item:selected {
                    background-color: #0078D7;
                }
            """)
            layout.addWidget(mic_list_widget)
            
            buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
            buttons.accepted.connect(dialog.accept)
            buttons.rejected.connect(dialog.reject)
            buttons.setStyleSheet("""
                QPushButton {
                    background-color: #0078D7;
                    color: #FFF;
                    border: none;
                    border-radius: 4px;
                    padding: 8px 20px;
                    font-size: 14px;
                }
                QPushButton:hover {
                    background-color: #106ebe;
                }
            """)
            layout.addWidget(buttons)
            
            if dialog.exec() == QDialog.DialogCode.Accepted:
                selected_items = mic_list_widget.selectedItems()
                if selected_items:
                    selected_name = selected_items[0].text()
                    self.microphone_device_index = mic_list.index(selected_name)
                    QMessageBox.information(self, "Microphone Selected", 
                                          f"Selected: {selected_name}\n\nYou can change this in settings later.")
                    # Now start listening
                    self.toggle_speech_recognition()
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Error setting up microphone: {e}")
            logging.error(f"Microphone setup error: {traceback.format_exc()}")
    
    def on_speech_listening(self):
        """Called when speech recognition starts listening"""
        self._update_conversation_status("Listening... Speak now!", "listening")
        self._update_tts_mic_status()
    
    def on_speech_recognition_finished(self, text: str):
        """Handle successful speech recognition"""
        self.is_listening = False
        if hasattr(self, 'mic_btn'):
            self.mic_btn.setText("🎤")
            self.mic_btn.setStyleSheet("background-color: #444; font-size: 20px; border-radius: 4px; padding: 4px;")
        
        # Insert recognized text into input box
        if text:
            current_text = self.input_box.toPlainText()
            if current_text:
                self.input_box.setPlainText(current_text + " " + text)
            else:
                self.input_box.setPlainText(text)
            self._update_conversation_status("Ready", "ready")
            self._update_tts_mic_status()
        else:
            self._update_conversation_status("No speech detected", "ready")
            self._update_tts_mic_status()
        
        # Clean up thread
        if self.speech_worker_thread:
            self.speech_worker_thread.quit()
            self.speech_worker_thread.wait()
            self.speech_worker_thread = None
            self.speech_worker = None
    
    def on_speech_recognition_error(self, error_msg: str):
        """Handle speech recognition error"""
        self.is_listening = False
        if hasattr(self, 'mic_btn'):
            self.mic_btn.setText("🎤")
            self.mic_btn.setStyleSheet("background-color: #444; font-size: 20px; border-radius: 4px; padding: 4px;")
        
        self._update_conversation_status(f"Error: {error_msg}", "error")
        self._update_tts_mic_status()
        # Show error popup with details
        QMessageBox.warning(self, "TTS/Mic Error", 
                           f"Speech Recognition Error:\n\n{error_msg}\n\n"
                           f"TTS Status: {'Active' if self.tts_enabled else 'Inactive'}\n"
                           f"Microphone: {'Listening' if self.is_listening else 'Not listening'}")
        
        # Clean up thread
        if self.speech_worker_thread:
            self.speech_worker_thread.quit()
            self.speech_worker_thread.wait()
            self.speech_worker_thread = None
            self.speech_worker = None

# =====================================================
# MAIN
# =====================================================

def main():
    import sys
    
    # Set up exception handling before creating QApplication
    def qt_exception_handler(exc_type, exc_value, exc_traceback):
        """Handle exceptions in Qt event loop"""
        if issubclass(exc_type, KeyboardInterrupt):
            sys.__excepthook__(exc_type, exc_value, exc_traceback)
            return
        
        # Log the exception
        handle_exception(exc_type, exc_value, exc_traceback)
    
    # Install Qt exception handler
    sys.excepthook = qt_exception_handler
    
    try:
        app = QApplication(sys.argv)
        
        # Set application properties for better error handling
        app.setQuitOnLastWindowClosed(True)
        
        splash = None
        try:
            if SPLASH_FILE.exists():
                splash = QSplashScreen(QPixmap(str(SPLASH_FILE)))
                splash.show()
                app.processEvents()
        except Exception as splash_error:
            logging.warning(f"Splash screen error: {splash_error}")
            splash = None
        
        try:
            window = LeaWindow()
            window.show()
            
            if splash:
                splash.finish(window)
        except Exception as window_error:
            logging.error(f"Window creation error: {traceback.format_exc()}")
            QMessageBox.critical(None, "Fatal Error", 
                               f"Failed to create window:\n{str(window_error)}\n\nCheck lea_crash.log for details.")
            sys.exit(1)
        
        try:
            sys.exit(app.exec())
        except Exception as app_error:
            logging.error(f"Application error: {traceback.format_exc()}")
            sys.exit(1)
            
    except Exception as main_error:
        logging.error(f"Main function error: {traceback.format_exc()}")
        print(f"Fatal error: {main_error}")
        print("Check lea_crash.log for details.")
        sys.exit(1)

if __name__ == "__main__":
    # Test import and basic initialization
    try:
        print("Testing Lea Assistant initialization...")
        main()
    except Exception as e:
        print(f"Error starting application: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
