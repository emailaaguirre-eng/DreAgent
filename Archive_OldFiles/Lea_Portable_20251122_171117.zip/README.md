# Lea Assistant - Portable Package

This package contains everything you need to run Lea on a new computer.

## Package Contents

- **Lea_Visual_Code_v2.5.1a_ TTS.py** - Main Lea program
- **requirements.txt** - Python package dependencies
- **lea_update_checker.py** - Automatic update checker
- **assets/** - Icons and splash screens
- **.env.example** - Environment variables template

## Setup Instructions

### 1. Install Python
- Download Python 3.8+ from https://www.python.org/
- Make sure to check "Add Python to PATH" during installation

### 2. Install Dependencies
Open a terminal/command prompt in this folder and run:
```bash
pip install -r requirements.txt
```

### 3. Configure Environment
1. Copy `.env.example` to `.env`
2. Edit `.env` and add your API keys:
   - `OPENAI_API_KEY` - Required (get from https://platform.openai.com/)
   - `OUTLOOK_CLIENT_ID` - Optional (for Outlook integration)
   - `OUTLOOK_TENANT_ID` - Optional (for Outlook integration)

### 4. Run Lea
```bash
python "Lea_Visual_Code_v2.5.1a_ TTS.py"
```

Or double-click the file if Python is associated with .py files.

## Features

- ✅ Multi-agent system (7 specialized modes)
- ✅ Outlook/Email integration
- ✅ Text-to-Speech
- ✅ Speech Recognition
- ✅ File reading and processing
- ✅ Task automation
- ✅ Automatic update checking
- ✅ Memory system
- ✅ And much more!

## Troubleshooting

- **Import errors**: Make sure all dependencies are installed (`pip install -r requirements.txt`)
- **API errors**: Check your `.env` file has correct API keys
- **Outlook not working**: Make sure you've set up Azure app registration and added Client ID to `.env`

## Support

For issues or questions, check the update system README or review the code comments.

---
Package created: 2025-11-22 17:11:17
